import { test } from 'node:test'
import assert from 'node:assert/strict'
import { RealtimeHost, SseChannel } from '../lib/realtime-host.js'
import { createFakeRealtimeProvider, FAKE_REALTIME_DEFAULTS } from '../lib/realtime-provider.js'

/**
 * I3 host 实时通道夹具：
 *   - 会话注册表：sid 由 host 铸造、不透明、无法伪造；生命周期 create → audio → events → close。
 *   - 4 条 exact 路由全部过 isTrusted（伪造 Host/Origin 即 403）。
 *   - SSE 下行背压：partial 可 coalesce、final/speech-stopped 必须最终送达。
 */

/** 极简 webserver register 替身：按 (kind, path) 存 handler，撞路径抛错（对齐官方契约）。 */
function makeRegistry() {
  const routes = new Map()
  const register = (def) => {
    const key = `${def.kind}:${def.path}`
    if (routes.has(key)) throw new Error(`duplicate route ${key}`)
    routes.set(key, def.handler)
    return () => { routes.delete(key) }
  }
  return { register, routes }
}

/** 可控的 ServerResponse 替身：记录写入、可手动触发 drain/close/背压。 */
class FakeRes {
  constructor() {
    this.headers = null
    this.body = ''
    this.drainCb = null
    this.closeCb = null
    this.ended = false
    this.writes = 0
    /** 内核缓冲满模拟：置 true 时 write 返回 false（drain 前一直背压）。 */
    this.backed = false
  }
  writeHead(status, headers) { this.status = status; this.headers = headers }
  flushHeaders() {}
  /**
   * 真实 `ServerResponse.write` 语义：**返回 false 不代表没写**——事件已被接受进内核
   * 缓冲、最终一定会送到对端，返回值只是「缓冲超水位，请等 drain 再写」。早先这里
   * 模拟成「背压 = 丢弃」，把实现里「返回 false 就不出队」的缺陷一起放过了（drain
   * 后同一条事件被重写一遍）。现在按真实语义建模：永远收下 chunk，背压只影响返回值。
   */
  write(chunk) {
    this.writes += 1
    this.body += chunk
    return !this.backed
  }
  once(event, cb) {
    if (event === 'drain') this.drainCb = cb
    if (event === 'close') this.closeCb = cb
  }
  on(event, cb) {
    if (event === 'close') this.closeCb = cb
  }
  removeListener() {}
  end(chunk) {
    // sendJson 走 res.end(body) 而不是 res.write：end 也要把 body 收进缓冲区，
    // 否则测试 JSON.parse(res.body) 拿到空串。
    if (chunk !== undefined) this.body += chunk
    this.ended = true
  }
}

/** 一条 SSE 响应里的所有 data 事件（按序）。 */
function sseEvents(res) {
  const out = []
  for (const line of res.body.split('\n')) {
    if (line.startsWith('data: ')) {
      out.push(JSON.parse(line.slice(6)))
    }
  }
  return out
}

/** 子串在响应体里出现几次（钉「不重复投递」用）。 */
function countOf(body, needle) {
  let n = 0
  let at = body.indexOf(needle)
  while (at !== -1) {
    n += 1
    at = body.indexOf(needle, at + needle.length)
  }
  return n
}

/** 16k int16 音频字节（一段音 / 一段静音）。 */
function toneBytes(ms, amp = 0.3) {
  const n = Math.round(16_000 * ms / 1000)
  const buf = new ArrayBuffer(n * 2)
  const view = new DataView(buf)
  for (let i = 0; i < n; i++) {
    const s = Math.sin(2 * Math.PI * 440 * i / 16_000) * amp
    view.setInt16(i * 2, Math.round(Math.max(-1, Math.min(1, s)) * 0x7fff), true)
  }
  return new Uint8Array(buf)
}
function silenceBytes(ms) {
  return new Uint8Array(Math.round(16_000 * ms / 1000) * 2)
}

/** 构造一个 RealtimeHost（假 provider + 关心跳，测试确定性）。 */
function makeHost(overrides = {}) {
  return new RealtimeHost({
    createProvider: () => createFakeRealtimeProvider({ ...FAKE_REALTIME_DEFAULTS, silenceMs: 600 }).connect(),
    heartbeatMs: 0,
    ...overrides,
  })
}

function reqOf(method, url, { origin, host = '127.0.0.1:3080', body } = {}) {
  const headers = {}
  if (origin !== undefined) headers.origin = origin
  headers.host = host
  if (body !== undefined) headers['content-length'] = String(body.byteLength)
  const req = { method, url, headers, body: body ?? new Uint8Array(0) }
  req[Symbol.asyncIterator] = async function* () {
    const chunk = Buffer.from(req.body)
    if (chunk.length > 0) yield chunk
  }
  return req
}

test('会话注册表：sid 由 host 铸造（UUID），create/close 生命周期', async () => {
  const host = makeHost()
  const { sid } = await host.createSession()
  assert.ok(/^[0-9a-f-]{36}$/.test(sid), 'sid 应为 UUID 形状')
  assert.ok(host.hasSession(sid))
  host.closeSession(sid)
  assert.ok(!host.hasSession(sid))
  // 幂等关闭
  host.closeSession(sid)
})

test('会话注册表：未知 sid 的 audio 返回 false、close 无副作用', async () => {
  const host = makeHost()
  assert.equal(host.feedAudio('no-such-sid', toneBytes(100)), false)
  host.closeSession('no-such-sid') // 不抛
})

test('路由注册：4 条路径全部唯一（无撞路径），disposer 可回收', async () => {
  const { register, routes } = makeRegistry()
  const host = makeHost()
  const dispose = host.registerRoutes(register)
  const paths = [...routes.keys()]
  assert.equal(paths.length, 4)
  for (const p of ['exact:/api/asr-voice/realtime/session', 'exact:/api/asr-voice/realtime/audio', 'exact:/api/asr-voice/realtime/events', 'exact:/api/asr-voice/realtime/close']) {
    assert.ok(paths.includes(p), `missing route ${p}`)
  }
  dispose()
  assert.equal(routes.size, 0)
})

test('路由信任围栏：4 条路由全部拒绝伪造 Origin', async () => {
  const reg = makeRegistry()
  const host = makeHost()
  host.registerRoutes(reg.register)
  const dispatch = (method, url, origin) => new Promise((resolve) => {
    const res = new FakeRes()
    const origEnd = res.end.bind(res)
    res.end = () => { resolve({ status: res.status, body: res.body }); origEnd() }
    const handler = reg.routes.get(`exact:${url.split('?')[0]}`)
    handler(reqOf(method, url, { origin }), res)
  })
  for (const [method, url] of [
    ['POST', '/api/asr-voice/realtime/session'],
    ['POST', '/api/asr-voice/realtime/audio?sid=x'],
    ['GET', '/api/asr-voice/realtime/events?sid=x'],
    ['POST', '/api/asr-voice/realtime/close?sid=x'],
  ]) {
    const res = await dispatch(method, url, 'http://evil.test')
    assert.equal(res.status, 403, `${method} ${url} 应被信任围栏拒绝`)
  }
})

test('POST session → POST audio → SSE events 全链路（假 provider 驱动）', async () => {
  const host = makeHost()
  const { register, routes } = makeRegistry()
  host.registerRoutes(register)

  // 1. 建会话
  let res = new FakeRes()
  await routes.get('exact:/api/asr-voice/realtime/session')(reqOf('POST', '/api/asr-voice/realtime/session'), res)
  const created = JSON.parse(res.body)
  assert.equal(created.ok, true)
  const sid = created.sid

  // 2. 上行 PCM（一段音 + 静音 → 假 provider 切出一句）
  res = new FakeRes()
  await routes.get('exact:/api/asr-voice/realtime/audio')(reqOf('POST', `/api/asr-voice/realtime/audio?sid=${sid}`, { body: toneBytes(400) }), res)
  assert.equal(JSON.parse(res.body).ok, true)
  res = new FakeRes()
  await routes.get('exact:/api/asr-voice/realtime/audio')(reqOf('POST', `/api/asr-voice/realtime/audio?sid=${sid}`, { body: silenceBytes(800) }), res)
  assert.equal(JSON.parse(res.body).ok, true)

  // 3. 挂 SSE 下行
  const sseRes = new FakeRes()
  const ssePromise = (async () => {
    await routes.get('exact:/api/asr-voice/realtime/events')(reqOf('GET', `/api/asr-voice/realtime/events?sid=${sid}`), sseRes)
    // 事件在 handler 返回前已由 attachSse 的 pending 冲刷入 body（假 provider 同步产出）
  })()
  await ssePromise
  assert.equal(sseRes.status, 200)
  assert.match(sseRes.headers['content-type'], /text\/event-stream/)

  // 4. 再上行音（SSE 挂起后的事件实时入 body）：音 + 静音 → 实时切出第二句
  res = new FakeRes()
  await routes.get('exact:/api/asr-voice/realtime/audio')(reqOf('POST', `/api/asr-voice/realtime/audio?sid=${sid}`, { body: toneBytes(400) }), res)
  assert.equal(JSON.parse(res.body).ok, true)
  res = new FakeRes()
  await routes.get('exact:/api/asr-voice/realtime/audio')(reqOf('POST', `/api/asr-voice/realtime/audio?sid=${sid}`, { body: silenceBytes(800) }), res)
  assert.equal(JSON.parse(res.body).ok, true)
  // 音 + 静音分两次 send（FakeRes 无法等待真实字节，这里直接验证已发生的事）
  const events = sseEvents(sseRes)
  const types = events.map((e) => e.type)
  assert.ok(types.includes('speech-started'))
  assert.ok(types.includes('speech-stopped'))
  const finals = events.filter((e) => e.type === 'final')
  assert.ok(finals.length >= 1, `expected >=1 final, got ${finals.length}`)
  assert.match(finals[0].text, /^模拟转写·第\d+段$/)

  // 5. close
  res = new FakeRes()
  await routes.get('exact:/api/asr-voice/realtime/close')(reqOf('POST', `/api/asr-voice/realtime/close?sid=${sid}`), res)
  assert.equal(JSON.parse(res.body).ok, true)
  assert.ok(!host.hasSession(sid))
})

test('SSE 挂起前的上行事件缓冲：先 audio 后 events 不丢事件', async () => {
  const host = makeHost()
  const { register, routes } = makeRegistry()
  host.registerRoutes(register)

  let res = new FakeRes()
  await routes.get('exact:/api/asr-voice/realtime/session')(reqOf('POST', '/api/asr-voice/realtime/session'), res)
  const sid = JSON.parse(res.body).sid

  // 先上行（此时 SSE 未挂，事件进 pending 缓冲）：音 + 静音 → 完整切出一句
  res = new FakeRes()
  await routes.get('exact:/api/asr-voice/realtime/audio')(reqOf('POST', `/api/asr-voice/realtime/audio?sid=${sid}`, { body: toneBytes(400) }), res)
  assert.equal(JSON.parse(res.body).ok, true)
  res = new FakeRes()
  await routes.get('exact:/api/asr-voice/realtime/audio')(reqOf('POST', `/api/asr-voice/realtime/audio?sid=${sid}`, { body: silenceBytes(800) }), res)
  assert.equal(JSON.parse(res.body).ok, true)

  // 后挂 SSE：缓冲被冲刷进 body
  const sseRes = new FakeRes()
  await routes.get('exact:/api/asr-voice/realtime/events')(reqOf('GET', `/api/asr-voice/realtime/events?sid=${sid}`), sseRes)
  const events = sseEvents(sseRes)
  assert.ok(events.some((e) => e.type === 'final'), '缓冲的上游事件应在挂 SSE 时送达')
  // 收尾：不 close 会让 10 分钟空闲定时器挂着，进程无法退出。
  host.closeSession(sid)
})

test('SSE 背压：命中背压的那条已送达（不得于 drain 后重写），partial 原位合并', async () => {
  // 真实 write 语义下 A 空闲直写；B 是「首条命中背压」的——它已经被写出，只是让通道
  // 进入背压态；C 在背压期间到达，最终被随后的 final 挤掉。
  const fakeRes = new FakeRes()
  const channel = new SseChannel(fakeRes, { heartbeatMs: 0 })

  channel.enqueue({ type: 'partial', text: 'A' }) // 缓冲空闲，正常写入
  fakeRes.backed = true // 内核缓冲满
  channel.enqueue({ type: 'partial', text: 'B' }) // 首条命中背压：已写出，通道转背压
  channel.enqueue({ type: 'partial', text: 'C' }) // 背压中：可丢的中间结果
  channel.enqueue({ type: 'final', text: '模拟转写·第1段' }) // 背压中：挤掉队尾 partial

  assert.ok(fakeRes.drainCb !== null, '应挂 drain 监听')
  assert.equal(countOf(fakeRes.body, '"A"'), 1, '空闲期的事件必须写出')
  assert.equal(countOf(fakeRes.body, '"B"'), 1, '命中背压的事件已写出且只写一次（旧实现在 drain 后重写）')
  assert.equal(fakeRes.body.includes('"C"'), false, '背压期的 partial 不进 body')

  fakeRes.backed = false // 内核缓冲释放
  fakeRes.drainCb() // drain 后冲刷
  assert.equal(countOf(fakeRes.body, '模拟转写·第1段'), 1, 'final 必须最终送达，且不重复')
  assert.deepEqual(
    sseEvents(fakeRes).map((e) => e.text ?? e.type),
    ['A', 'B', '模拟转写·第1段'],
    '保序、不重复、不丢 final',
  )
  assert.ok(!fakeRes.body.includes('"C"'), '中间 partial 被 coalesce')

  channel.close()
})

test('SSE 背压：backed 期间 speech-stopped 不被队尾 partial 挤掉', async () => {
  const fakeRes = new FakeRes()
  const channel = new SseChannel(fakeRes, { heartbeatMs: 0 })
  fakeRes.backed = true
  channel.enqueue({ type: 'speech-started' }) // 首条命中背压：已写出，通道转背压
  channel.enqueue({ type: 'partial', text: 'x' }) // 背压中：可丢
  channel.enqueue({ type: 'speech-stopped' }) // 不可丢：挤掉队尾 partial
  fakeRes.backed = false
  fakeRes.drainCb()
  const events = sseEvents(fakeRes)
  assert.deepEqual(events.map((e) => e.type), ['speech-started', 'speech-stopped'])
  channel.close()
})

test('SSE 背压：连续两句 final 都不丢、不重复（旧的单 coalesce 槽会顶掉第一句）', async () => {
  const fakeRes = new FakeRes()
  const channel = new SseChannel(fakeRes, { heartbeatMs: 0 })
  fakeRes.backed = true
  channel.enqueue({ type: 'final', text: '第一句的最终结果' }) // 首条命中背压：已写出，通道转背压
  channel.enqueue({ type: 'partial', text: '第二句的草稿' }) // 会被随后的 final₂ 合并（冗余预览）
  channel.enqueue({ type: 'final', text: '第二句的最终结果' })
  fakeRes.backed = false
  fakeRes.drainCb()
  const events = sseEvents(fakeRes)
  assert.deepEqual(events.map((e) => e.text), ['第一句的最终结果', '第二句的最终结果'], '两句的 final 都必须送达且各一次')
  channel.close()
})

test('SSE 背压：final 之后的 partial 不得覆盖 final（同句 partial 才原位合并）', async () => {
  const fakeRes = new FakeRes()
  const channel = new SseChannel(fakeRes, { heartbeatMs: 0 })
  fakeRes.backed = true
  channel.enqueue({ type: 'final', text: '这句说完了' }) // 首条命中背压：已写出，通道转背压
  channel.enqueue({ type: 'partial', text: '下一句的预览' })
  fakeRes.backed = false
  fakeRes.drainCb()
  const events = sseEvents(fakeRes)
  assert.deepEqual(events.map((e) => e.type), ['final', 'partial'], 'final 不可被后续 partial 顶掉')
  assert.equal(events[0].text, '这句说完了')
  channel.close()
})

test('SSE close 幂等：重复 close 不抛、end 只调用一次', async () => {
  const fakeRes = new FakeRes()
  const channel = new SseChannel(fakeRes, { heartbeatMs: 0 })
  channel.close()
  channel.close()
  assert.equal(fakeRes.ended, true)
})

test('空闲超时：会话自动拆除（防泄漏）', async () => {
  let clock = 0
  const host = makeHost({ idleMs: 500, now: () => clock })
  const { sid } = await host.createSession()
  assert.ok(host.hasSession(sid))
  // 定时器触发前把时钟推到超过 idle：下一次 tick 判定空闲并拆除。
  clock = 10_000
  await new Promise((r) => setTimeout(r, 700))
  assert.ok(!host.hasSession(sid), '空闲会话应被自动拆除')
})

test('dispose()：插件卸载时逐个关闭活动会话（幂等，挂着的 SSE 一起释放）', async () => {
  const host = makeHost()
  const { sid: sid1 } = await host.createSession()
  const { sid: sid2 } = await host.createSession()
  // 给 sid1 挂一条 SSE：dispose 必须把下行通道一起关掉（心跳/close 监听随之释放）。
  const sseRes = new FakeRes()
  assert.equal(host.attachSse(sid1, sseRes), true)
  assert.ok(host.hasSession(sid1) && host.hasSession(sid2))

  host.dispose()
  assert.ok(!host.hasSession(sid1) && !host.hasSession(sid2), 'dispose 后所有会话应被拆除')
  assert.equal(sseRes.ended, true, '挂着的 SSE 下行应随 dispose 关闭')
  assert.equal(host.feedAudio(sid1, toneBytes(100)), false, '已拆除会话不再接受上行')
  // 幂等：重复 dispose 不抛、无副作用。
  host.dispose()
})

test('SSE 背压：pending 满 cap 时溢出只丢 partial/最旧 final，新 final 必达', async () => {
  const fakeRes = new FakeRes()
  const channel = new SseChannel(fakeRes, { heartbeatMs: 0 })
  fakeRes.backed = true
  // 首条命中背压的事件**已写出**（只是让通道转背压态），因此它不占队列额度。
  channel.enqueue({ type: 'final', text: 'final-0' })
  // 再填满 64 条 final（全队都是不可丢的回合边界）。
  for (let i = 1; i <= 64; i++) channel.enqueue({ type: 'final', text: `final-${i}` })
  // 再来一条 partial：溢出必须优先丢新来的 partial，64 条 final 一条不能少
  //（旧实现 shift() 会丢掉最旧的 final，违反「final 必达」契约）。
  channel.enqueue({ type: 'partial', text: '可丢的中间结果' })
  // 再来一条 final：此时全队都是 final，才允许丢最旧（丢 final-1，保 final-65）。
  channel.enqueue({ type: 'final', text: 'final-65' })

  fakeRes.backed = false
  fakeRes.drainCb()
  const events = sseEvents(fakeRes)
  // 1 条已直写 + 队列 64 条：队列本身有界，直写的那条不重复。
  assert.equal(events.length, 65, '队列有界：溢出只降级，不无界增长')
  assert.equal(events[0].text, 'final-0', '首条命中背压的事件已送出且不重复')
  assert.equal(events[1].text, 'final-2', '全 final 溢出丢最旧（final-1），新 final 保序')
  assert.equal(events[64].text, 'final-65', '最新 final 必达')
  assert.ok(!events.some((e) => e.type === 'partial'), '溢出优先丢新来的 partial')
  assert.ok(!events.some((e) => e.text === 'final-1'), '仅当全队都是 final 才允许丢最旧')
  channel.close()
})

// ── 上游报错后的会话收尾（僵尸会话修复）─────────────────────────────────────
// 缺陷形态：provider 报错后 host 不拆会话，而客户端仍按 40ms 一帧上行 PCM，每帧
// `feedAudio` → `refreshIdle` 都把 lastActive 顶到现在 → 死连接的会话永远等不到空闲
// 过期，SSE 一直挂着、麦克风一直开。修法：终态报错即进入「拒绝上行 + 不续命 + 短窗拆除」，
// 非终态报错（单条转写失败）不动会话。

/** 可手动推事件的上游连接替身（真 provider 的报错时机由测试掌控）。 */
function makeManualProvider() {
  const conns = []
  const provider = {
    connect: async () => {
      const conn = {
        onEvent: null,
        sent: [],
        closed: false,
        send(pcm) { this.sent.push(pcm) },
        close() { this.closed = true },
      }
      conns.push(conn)
      return conn
    },
  }
  return { provider, conns }
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

test('终态报错：拒绝后续上行（不再续命），宽限期到点拆除会话', async () => {
  const { provider, conns } = makeManualProvider()
  // idleMs 设成 10 分钟：会话若被拆，只可能是「报错收尾」生效，不是空闲自然过期。
  const host = new RealtimeHost({ createProvider: () => provider.connect(), idleMs: 10 * 60 * 1000, errorLingerMs: 40, heartbeatMs: 0 })
  const { sid } = await host.createSession()
  const conn = conns[0]

  // 对照组：报错前上行成功且被转发给上游。
  assert.equal(host.feedAudio(sid, toneBytes(40)), true)
  assert.equal(conn.sent.length, 1)

  conn.onEvent({ type: 'error', code: 'provider-closed', fatal: true })
  assert.ok(host.hasSession(sid), '报错当刻会话还在（错误帧要先有机会送达）')

  // 关键断言：报错后上行被拒 —— 客户端再怎么发帧都不能给死连接续命。
  assert.equal(host.feedAudio(sid, toneBytes(40)), false, '终态报错后不再接受上行')
  assert.equal(conn.sent.length, 1, '被拒的上行不得转发给已死的上游')

  await sleep(120)
  assert.ok(!host.hasSession(sid), '宽限期到点后会话应被拆除（不再永久滞留）')
  assert.equal(conn.closed, true, '上游连接应随之释放')
})

test('非终态报错（单条转写失败）：不拆会话，后续上行照常', async () => {
  const { provider, conns } = makeManualProvider()
  const host = new RealtimeHost({ createProvider: () => provider.connect(), idleMs: 10 * 60 * 1000, errorLingerMs: 30, heartbeatMs: 0 })
  const { sid } = await host.createSession()
  const conn = conns[0]

  // qwen 的 …transcription.failed 是单项失败（官方文档：与其他 error 事件分开处理），
  // 连接仍活、后续回合照常——拆会话等于用户说错一句就掐掉整场对话。
  conn.onEvent({ type: 'error', code: 'transcription-failed', fatal: false })
  assert.equal(host.feedAudio(sid, toneBytes(40)), true, '非终态报错后上行必须照常')
  await sleep(80)
  assert.ok(host.hasSession(sid), '非终态报错不得拆除会话')
  host.closeSession(sid)
})

test('终态报错：错误帧仍送达 SSE（收尾不吞掉错误原因）', async () => {
  const { provider, conns } = makeManualProvider()
  const host = new RealtimeHost({ createProvider: () => provider.connect(), idleMs: 10 * 60 * 1000, errorLingerMs: 40, heartbeatMs: 0 })
  const { sid } = await host.createSession()
  const sseRes = new FakeRes()
  assert.equal(host.attachSse(sid, sseRes), true)

  conns[0].onEvent({ type: 'error', code: 'provider-unreachable', fatal: true })
  const events = sseEvents(sseRes)
  assert.deepEqual(events, [{ type: 'error', code: 'provider-unreachable', fatal: true }], '错误帧必须先送出再收尾')

  await sleep(120)
  assert.ok(!host.hasSession(sid), '宽限期到点后会话应被拆除')
  assert.equal(sseRes.ended, true, 'SSE 下行应随会话关闭（客户端据此结束并释放麦克风）')
  host.dispose()
})

test('终态报错：SSE 未挂时错误帧留缓冲，挂上后补送', async () => {
  const { provider, conns } = makeManualProvider()
  const host = new RealtimeHost({ createProvider: () => provider.connect(), idleMs: 10 * 60 * 1000, errorLingerMs: 200, heartbeatMs: 0 })
  const { sid } = await host.createSession()

  conns[0].onEvent({ type: 'error', code: 'provider-timeout', fatal: true })
  // SSE 还没连上（建连有延迟）：此时不能把会话直接删掉，否则错误原因丢失。
  assert.ok(host.hasSession(sid))
  const sseRes = new FakeRes()
  assert.equal(host.attachSse(sid, sseRes), true)
  assert.deepEqual(sseEvents(sseRes), [{ type: 'error', code: 'provider-timeout', fatal: true }], '挂上 SSE 应补送缓冲的错误帧')
  host.closeSession(sid)
})

test('audio 路由：超限 PCM 回 413（不再笼统回 400）', async () => {
  const host = makeHost()
  const { register, routes } = makeRegistry()
  host.registerRoutes(register)
  let res = new FakeRes()
  await routes.get('exact:/api/asr-voice/realtime/session')(reqOf('POST', '/api/asr-voice/realtime/session'), res)
  const sid = JSON.parse(res.body).sid

  // 4MB + 1：刚好越过 MAX_PCM_BYTES（客户端发这么大的单帧本身已是异常）。
  res = new FakeRes()
  await routes.get('exact:/api/asr-voice/realtime/audio')(
    reqOf('POST', `/api/asr-voice/realtime/audio?sid=${sid}`, { body: new Uint8Array(4 * 1024 * 1024 + 1) }),
    res,
  )
  assert.equal(res.status, 413, `超限应回 413，实际 ${res.status}`)
  assert.match(JSON.parse(res.body).reason, /exceeds/)
  host.closeSession(sid)
})

test('audio 路由：会话不存在仍回 404（不受状态码映射影响）', async () => {
  const host = makeHost()
  const { register, routes } = makeRegistry()
  host.registerRoutes(register)
  const res = new FakeRes()
  await routes.get('exact:/api/asr-voice/realtime/audio')(
    reqOf('POST', '/api/asr-voice/realtime/audio?sid=no-such', { body: toneBytes(40) }),
    res,
  )
  assert.equal(res.status, 404)
})

// ── 容量与生命周期兜底（host 侧不信客户端的自觉）─────────────────────────────
// 缺陷形态：createSession 只 randomUUID + set（无数量上限），而 realtime.maxSessionMs
// 只在客户端生效——页面卡死/被挂起时不会发停止请求，云端付费 WS 与心跳 interval 就
// 再没人回收；refreshIdle 还在每次上行（40ms 一帧）重挂 idle timer。

test('会话数上限：超出时创建路由回 503（且不先开上游连接）', async () => {
  const { provider, conns } = makeManualProvider()
  const host = new RealtimeHost({ createProvider: () => provider.connect(), maxSessions: 2, heartbeatMs: 0 })
  const { register, routes } = makeRegistry()
  host.registerRoutes(register)
  const create = async () => {
    const res = new FakeRes()
    await routes.get('exact:/api/asr-voice/realtime/session')(reqOf('POST', '/api/asr-voice/realtime/session'), res)
    return { status: res.status, body: JSON.parse(res.body) }
  }

  const first = await create()
  const second = await create()
  assert.equal(first.body.ok, true)
  assert.equal(second.body.ok, true)

  const third = await create()
  assert.equal(third.status, 503, '容量问题是 503（可重试），不是 502 上游故障')
  assert.match(third.body.reason, /too many realtime sessions/)
  assert.equal(conns.length, 2, '被拒的创建不得先开一条云端付费 WS')
  assert.equal(host.sessionCount(), 2)

  // 容量随关闭回收：腾出位置后能再建。
  host.closeSession(first.body.sid)
  const fourth = await create()
  assert.equal(fourth.body.ok, true)
  host.dispose()
})

test('绝对 TTL：持续上行也不续命，到点无条件拆会话', async () => {
  const { provider, conns } = makeManualProvider()
  // idleMs 设成 10 分钟：会话若被拆，只可能是绝对 TTL 生效。
  const host = new RealtimeHost({ createProvider: () => provider.connect(), maxSessionMs: 60, idleMs: 10 * 60 * 1000, heartbeatMs: 0 })
  const { sid } = await host.createSession()

  // 客户端每 10ms 一帧地持续上行（就是「把空闲守卫永远续命」的那种用法）。
  const tick = setInterval(() => { host.feedAudio(sid, toneBytes(40)) }, 10)
  await sleep(200)
  clearInterval(tick)

  assert.ok(!host.hasSession(sid), '绝对 TTL 到点必须拆会话（不看是否有活动）')
  assert.equal(conns[0].closed, true, '上游连接应随之释放')
  assert.equal(host.sessionCount(), 0)
  host.dispose()
})

test('绝对 TTL：取值每次建会话现读（settings 热改只影响新会话）', async () => {
  let ttl = 0 // 0 = 显式关闭绝对上限
  const { provider } = makeManualProvider()
  const host = new RealtimeHost({
    createProvider: () => provider.connect(),
    maxSessionMs: () => ttl,
    idleMs: 10 * 60 * 1000,
    heartbeatMs: 0,
  })
  const unlimited = await host.createSession()
  await sleep(40)
  assert.ok(host.hasSession(unlimited.sid), 'TTL 非正数 = 不设绝对上限')

  ttl = 40
  const limited = await host.createSession()
  await sleep(120)
  assert.ok(!host.hasSession(limited.sid), '新会话应吃到新 TTL')
  assert.ok(host.hasSession(unlimited.sid), '已在跑的会话不受热改影响')
  host.dispose()
})

test('空闲定时器重挂节流：1s 内的连续上行不再逐帧重挂', async () => {
  const { provider } = makeManualProvider()
  let clock = 1_000_000
  const host = new RealtimeHost({
    createProvider: () => provider.connect(),
    idleMs: 10 * 60 * 1000,
    heartbeatMs: 0,
    now: () => clock,
  })
  const { sid } = await host.createSession()

  const realSetTimeout = globalThis.setTimeout
  let armed = 0
  globalThis.setTimeout = (fn, ms) => { armed += 1; return realSetTimeout(fn, ms) }
  try {
    // 5 帧 × 40ms = 200ms，仍在 1s 节流窗口内：一次都不该重挂。
    for (let i = 0; i < 5; i++) {
      clock += 40
      assert.equal(host.feedAudio(sid, toneBytes(40)), true)
    }
    assert.equal(armed, 0, '节流窗口内的上行不该重挂 idle timer')
    // 越过窗口后重挂一次（lastActive 一直在更新，故不会误拆）。
    clock += 1_100
    host.feedAudio(sid, toneBytes(40))
    assert.equal(armed, 1, '越过节流窗口应重挂一次')
  } finally {
    globalThis.setTimeout = realSetTimeout
  }
  assert.ok(host.hasSession(sid), '节流不得把活跃会话判成空闲')
  host.closeSession(sid)
})

test('SSE 重复消费者 → 409（不写 SSE 头），首个连接不受影响', async () => {
  const host = makeHost()
  const { register, routes } = makeRegistry()
  host.registerRoutes(register)
  let res = new FakeRes()
  await routes.get('exact:/api/asr-voice/realtime/session')(reqOf('POST', '/api/asr-voice/realtime/session'), res)
  const sid = JSON.parse(res.body).sid

  // 首个下行：正常 200 + SSE 头。
  const first = new FakeRes()
  await routes.get('exact:/api/asr-voice/realtime/events')(reqOf('GET', `/api/asr-voice/realtime/events?sid=${sid}`), first)
  assert.equal(first.status, 200)
  assert.match(first.headers['content-type'], /text\/event-stream/)
  assert.ok(host.hasSseConsumer(sid), '首连后应有权威下行')

  // 第二个下行：必须 409，且**不能**写 SSE 头（写了就再也改不了状态码，
  // 客户端会收到 200 + 空 body，判 events-unavailable → failNow 把会话判死）。
  const second = new FakeRes()
  await routes.get('exact:/api/asr-voice/realtime/events')(reqOf('GET', `/api/asr-voice/realtime/events?sid=${sid}`), second)
  assert.equal(second.status, 409)
  assert.equal(JSON.parse(second.body).reason, 'events stream already attached')
  // 409 走 sendJson（json 头），绝不是 SSE 头——客户端靠 status 区分，
  // 而不是靠 content-type。
  assert.equal(second.headers['content-type'], 'application/json; charset=utf-8')
  assert.ok(host.hasSession(sid), '重复消费者不得拆掉会话')
  assert.ok(host.hasSseConsumer(sid), '权威下行仍是第一个')

  host.closeSession(sid)
})

test('SSE 会话不存在 → 404（客户端据此结束会话）', async () => {
  const host = makeHost()
  const { register, routes } = makeRegistry()
  host.registerRoutes(register)
  const res = new FakeRes()
  await routes.get('exact:/api/asr-voice/realtime/events')(reqOf('GET', '/api/asr-voice/realtime/events?sid=nope'), res)
  assert.equal(res.status, 404)
  assert.equal(JSON.parse(res.body).reason, 'no such session')
  assert.equal(res.headers['content-type'], 'application/json; charset=utf-8', '404 走 sendJson，不是 SSE 头')
})
