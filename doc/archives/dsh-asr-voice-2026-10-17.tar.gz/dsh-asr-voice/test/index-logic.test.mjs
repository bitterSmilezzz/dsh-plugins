import { test } from 'node:test'
import assert from 'node:assert/strict'

/**
 * host 组合逻辑单测：providerView / resolveCloudProvider / listProviders /
 * migrateLegacyKeys（src/index.ts 内部导出——纯函数或依赖可注入，无需 Cordis mock 基座）。
 * 注意：不能 import '../src/index.ts'（import 链里 realtime-dashscope.ts 用了 TS
 * parameter property，node strip-only 不支持），与 realtime-dashscope.test.mjs 一致
 * 走构建产物 lib/index.js；改动 src/index.ts 后需先重建 lib 再跑本文件。
 */
import { providerView, resolveCloudProvider, listProviders, migrateLegacyKeys, isVolatileRef } from '../lib/index.js'
import { keyRefFor } from '../lib/key-ref.js'

/** 组装一份 AsrVoiceSettings 的最小形状（asr.cloud 为唯一读取面）。 */
function settingsWith(cloud) {
  return { asr: { provider: 'auto', cloud } }
}

test('providerView: 缺省兜底（preset=openai、mode=auto、其余空串、id 用 fallback）', () => {
  assert.deepEqual(providerView({}, 'provider'), {
    id: 'provider', preset: 'openai', name: '', baseUrl: '', apiKey: '', model: '', mode: 'auto',
  })
})

test('providerView: 行内值保留；modeOverride 优先于行内 mode', () => {
  const row = { id: 'p1', preset: 'dashscope', name: '百炼', baseUrl: 'https://x', apiKey: 'k', model: 'm', mode: 'chat' }
  assert.deepEqual(providerView(row, 'fallback'), row)
  assert.equal(providerView(row, 'fallback', 'auto').mode, 'auto', '显式 override 优先')
  assert.equal(providerView({ mode: 'chat' }, 'x').mode, 'chat')
  assert.equal(providerView({}, 'x', 'transcriptions').mode, 'transcriptions')
})

test('resolveCloudProvider: 多供应商按 active 取行，active 不命中回退首个', () => {
  const v = settingsWith({
    active: 'p2',
    providers: [
      { id: 'p1', preset: 'openai', model: 'whisper-1' },
      { id: 'p2', preset: 'dashscope', model: 'qwen', name: '百炼' },
    ],
  })
  assert.deepEqual(resolveCloudProvider(v), {
    id: 'p2', preset: 'dashscope', name: '百炼', baseUrl: '', apiKey: '', model: 'qwen', mode: 'auto',
  })
  assert.equal(resolveCloudProvider(settingsWith({ active: 'nope', providers: [{ id: 'p1' }] })).id, 'p1')
})

test('resolveCloudProvider: 旧单配置（无 providers 数组）合成 legacy 行', () => {
  const v = settingsWith({ preset: 'openai', baseUrl: 'https://legacy', apiKey: 'old-key', model: 'whisper-1' })
  assert.deepEqual(resolveCloudProvider(v), {
    id: 'legacy', preset: 'openai', name: '', baseUrl: 'https://legacy', apiKey: 'old-key', model: 'whisper-1', mode: 'auto',
  })
  assert.equal(resolveCloudProvider(undefined), undefined, '无 settings 应返回 undefined')
})

test('listProviders: 多供应商全列；旧单配置合成一个 legacy；无配置为空', () => {
  assert.equal(listProviders(undefined).length, 0)
  assert.deepEqual(listProviders(settingsWith({ providers: [] })), [], '无 providers 且无 baseUrl → 空列表')
  assert.deepEqual(
    listProviders(settingsWith({ providers: [{ id: 'p1', preset: 'openai' }], baseUrl: 'x' })),
    [{ id: 'p1', preset: 'openai', name: '', baseUrl: '', apiKey: '', model: '', mode: 'auto' }],
  )
  const legacy = listProviders(settingsWith({ preset: 'openai', baseUrl: 'https://legacy' }))
  assert.equal(legacy.length, 1)
  assert.equal(legacy[0].id, 'legacy')
  assert.equal(legacy[0].baseUrl, 'https://legacy')
})

/** 假 scope：get 返回深度冻结快照（镜像真实 settings 服务的冻结解析），update 记 patch。 */
function makeScope(initial) {
  const updates = []
  const snapshot = () => JSON.parse(JSON.stringify(initial))
  let current = snapshot()
  return {
    get: () => Object.freeze(current),
    update: async (patch) => { updates.push(JSON.parse(JSON.stringify(patch))); current = snapshot() },
    updates,
  }
}

const NOOP_LOG = { warn: () => {}, info: () => {} }

test('migrateLegacyKeys: credentials 缺席 → 整批跳过 + warn 一条（不读 scope、不写）', async () => {
  let got = 0
  const warns = []
  const scope = { get: () => { got += 1; throw new Error('不应被读取') }, update: async () => { throw new Error('不应被写') } }
  await migrateLegacyKeys(scope, undefined, { warn: (m) => { warns.push(m) }, info: () => {} })
  assert.equal(got, 0)
  // 静默返回会让用户以为「已经搬完了」——明文 key 其实还在 settings 里躺着。
  assert.equal(warns.length, 1, '凭据服务不可用必须留一条 warn')
  assert.match(warns[0], /credentials service unavailable/)
  assert.match(warns[0], /not migrated/)
})

test('migrateLegacyKeys: 无遗留 key → 空转早退（不 set、不 update、不记日志）', async () => {
  const scope = makeScope(settingsWith({ providers: [{ id: 'p1', preset: 'openai', apiKey: '   ' }], apiKey: '' }))
  const sets = []
  const log = { warn: () => { throw new Error('不应 warn') }, info: () => { throw new Error('不应 info') } }
  await migrateLegacyKeys(scope, { set: async (ref, key) => { sets.push([ref, key]) } }, log)
  assert.deepEqual(sets, [])
  assert.deepEqual(scope.updates, [])
})

test('migrateLegacyKeys: 全量搬成功 → 抹掉明文（providers 各行 + 遗留 apiKey）并记 info', async () => {
  const scope = makeScope(settingsWith({
    preset: 'openai',
    apiKey: 'legacy-secret',
    providers: [
      { id: 'p1', preset: 'openai', apiKey: 'key-a' },
      { id: 'p2', preset: 'custom-x', name: 'My Provider', apiKey: 'key-b' },
    ],
  }))
  const sets = []
  const infos = []
  await migrateLegacyKeys(scope, { set: async (ref, key) => { sets.push([ref, key]) } }, { warn: () => {}, info: (m) => { infos.push(m) } })
  // 预置 id → <PRESET>_API_KEY（复用官方 LLM 同名凭据）；自定义 → ASR_VOICE_<NAME>_API_KEY；
  // 旧单配置 legacy → 按行内 preset 派生。
  assert.deepEqual(sets, [
    ['OPENAI_API_KEY', 'key-a'],
    ['ASR_VOICE_MY_PROVIDER_API_KEY', 'key-b'],
    ['OPENAI_API_KEY', 'legacy-secret'],
  ])
  assert.deepEqual(scope.updates, [{ asr: { cloud: { providers: [
    { id: 'p1', preset: 'openai', apiKey: '' },
    { id: 'p2', preset: 'custom-x', name: 'My Provider', apiKey: '' },
  ], apiKey: '' } } }])
  assert.equal(infos.length, 1)
  assert.match(infos[0], /moved 3 API key/)
})

test('migrateLegacyKeys: 任一条 set 被拒 → 停止迁移、明文保留（不 update）、warn 带原因', async () => {
  const scope = makeScope(settingsWith({
    preset: 'openai',
    providers: [{ id: 'p1', preset: 'openai', apiKey: 'key-a' }, { id: 'p2', preset: 'openai', apiKey: 'key-b' }],
  }))
  const sets = []
  const warns = []
  await migrateLegacyKeys(scope, {
    set: async (ref, key) => {
      sets.push(ref)
      if (ref === 'OPENAI_API_KEY' && sets.length === 2) throw new Error('readonly source')
    },
  }, { warn: (m) => { warns.push(m) }, info: () => {} })
  assert.deepEqual(sets, ['OPENAI_API_KEY', 'OPENAI_API_KEY'], '第二条被拒后不再尝试后续')
  assert.deepEqual(scope.updates, [], '迁移未完成 → 明文 key 必须原样保留（抹掉就无处可寻）')
  assert.equal(warns.length, 1)
  assert.match(warns[0], /credentials\.set\(OPENAI_API_KEY\) refused: readonly source/)
})

test('migrateLegacyKeys: 抹明文失败（update 拒写）→ warn 点名半数态，不谎报完成', async () => {
  // 走到这儿 key 已全部进 credentials、settings 里的明文还在 = 迁移做了一半。旧实现
  // 让异常冒到 migrateLegacyKeys 的 .catch() 只落一句 warn，用户看不到是哪一半没做完。
  const scope = makeScope(settingsWith({ preset: 'openai', providers: [{ id: 'p1', preset: 'openai', apiKey: 'key-a' }] }))
  scope.update = async () => { throw new Error('config entry not writable') }
  const warns = []
  const infos = []
  await migrateLegacyKeys(scope, { set: async () => {} }, { warn: (m) => { warns.push(m) }, info: (m) => { infos.push(m) } })
  assert.deepEqual(infos, [], '没抹成功就不得记「moved N API key(s)」——那是谎报完成')
  assert.equal(warns.length, 1)
  assert.match(warns[0], /clearing plugin settings failed: config entry not writable/)
  // 关键：warn 必须同时说清「钥匙在哪」和「现状可恢复」，别只说一句失败。
  assert.match(warns[0], /keys moved into credentials/)
  assert.match(warns[0], /plaintext keys remain in settings/)
  assert.match(warns[0], /retried on next start/)
})

// ── 引用名派生必须唯一（迁移写入的 ref 必须就是读取路径读的 ref）───────────────
// 缺陷形态：读取路径（resolveCloudProvider / listProviders）先过 providerView 兜底
// id='provider' 再 keyRefFor，而迁移路径直接拿原始行 keyRefFor。行缺 id/name 时两条
// 路径分叉（读 ASR_VOICE_PROVIDER_API_KEY、写 ASR_VOICE_CUSTOM_API_KEY），明文一被
// 抹掉，密钥就写进了一个没人读的引用名里——彻底不可达。

test('migrateLegacyKeys: 行缺 id/name 时，写入的 ref 与读取路径派生的 ref 完全一致', async () => {
  const rows = [
    { id: '', preset: 'custom', name: '', apiKey: 'secret-a' },   // 两条路径原先分叉的那一行
    { id: 'p2', preset: 'custom', name: '', apiKey: 'secret-b' }, // 有 id、无 name
    { id: '', preset: 'openai', name: '', apiKey: 'secret-c' },   // 预置 id 不受影响（对照组）
  ]
  const scope = makeScope(settingsWith({ providers: rows }))
  const sets = []
  await migrateLegacyKeys(scope, { set: async (ref, key) => { sets.push([ref, key]) } }, NOOP_LOG)
  assert.equal(sets.length, 3)

  // 读取路径：迁移后的快照（key 已抹掉）逐行派生 —— 与迁移写入的 ref 必须逐行相等。
  const readRefs = listProviders(scope.get()).map((p) => keyRefFor(p))
  assert.deepEqual(sets.map(([ref]) => ref), readRefs, '迁移与读取必须走同一个派生入口')
  // 钉住具体形状：缺 id/name 的行读取路径兜底 id='provider'（不是 'CUSTOM'）。
  assert.equal(sets[0][0], 'ASR_VOICE_PROVIDER_API_KEY')
  assert.equal(sets[1][0], 'ASR_VOICE_P2_API_KEY')
  assert.equal(sets[2][0], 'OPENAI_API_KEY')
})

test('migrateLegacyKeys: 旧单配置的 ref 与 resolveCloudProvider 派生的 ref 一致', async () => {
  const scope = makeScope(settingsWith({ preset: 'custom', baseUrl: 'https://x', apiKey: 'legacy-secret', providers: [] }))
  const sets = []
  await migrateLegacyKeys(scope, { set: async (ref, key) => { sets.push([ref, key]) } }, NOOP_LOG)
  const readRef = keyRefFor(resolveCloudProvider(scope.get()))
  assert.equal(sets[0][0], readRef)
  assert.equal(sets[0][0], 'ASR_VOICE_LEGACY_API_KEY')
})

// ── volatile 剥引判据必须与官方一致 ─────────────────────────────────────────
// 缺陷形态：判据只用「有 get 方法」。Cordis 的 volatile 引用是 cosmokit 的
// `Symbol.for('cosmokit.volatile.write')` 品牌对象，不同 ESM/CJS 副本、或上游换成
// write-only 形态时，引用可能只有品牌 symbol 而没有 get → 插件把它当普通对象递归，
// `plainSettings` 返回一个带 `get` 的假快照，整棵配置读成 undefined——无编译错、
// 无运行错，正是本插件最怕的静默失效。反向也一样：任何带 get 的业务对象会被误剥一层。

test('isVolatileRef: 品牌 symbol 命中即判 volatile（官方 isVolatile 同款判据）', () => {
  const brand = Symbol.for('cosmokit.volatile.write')
  // 只有品牌、没有 get：旧判据会漏剥。
  const brandOnly = { [brand]: () => {} }
  assert.equal(isVolatileRef(brandOnly), true, '只带品牌 symbol 的引用必须判 volatile')
  // 品牌 + get：正常形态。
  const both = { [brand]: () => {}, get: () => 42 }
  assert.equal(isVolatileRef(both), true)
})

test('isVolatileRef: get 方法作兼容回退（无品牌的旧形状仍判 volatile）', () => {
  assert.equal(isVolatileRef({ get: () => 42 }), true)
  assert.equal(isVolatileRef({ get: () => 42, other: 1 }), true)
})

test('isVolatileRef: 普通值一律不判 volatile', () => {
  for (const value of [null, undefined, 42, 'x', true, [], {}, { nested: { get: 1 } }]) {
    assert.equal(isVolatileRef(value), false, `${JSON.stringify(value) ?? String(value)} 不是 volatile 引用`)
  }
})
