/** dsh-asr-voice — host 半区：LLM 提示词优化。
 * 提示词优化只使用 **DSH 已配置好的模型**（ctx.llm 通道）：
 * - 请求可指定 { provider, model }（必须是 DSH 模型列表里已配置的）
 * - 未指定 → 用当前所选 LLM（ctx.agentDefaultModel.currentSelection()）
 * 要自定义模型，须先到 DSH 原生模型列表添加（本插件不做独立 baseUrl/apiKey）。
 * /api/asr-voice/models 枚举 DSH 已配置模型（供设置页选择器）。
 * API key 由 DSH provider 管理，全程在服务端；跨平台。
 */
import type { Context } from '@deepseek-ai/cordis';
import type { IncomingMessage, ServerResponse } from 'node:http';
import { createUserMessage } from '@deepseek-ai/dsh-llm';
// DSH 0.1.7 起 MessageSourceMap 不再有共享的 `plugin` 兜底 kind（每个生产方在
// 自己的模块里声明自己的 kind，官方 user-approval / model-selection / webhook 均如此）。
declare module '@deepseek-ai/dsh-llm' {
  interface MessageSourceMap {
    /** LLM 提示词优化代理发出的用户消息（content 由本插件清洗过的转写文本组装）。 */
    'asr-voice': { readonly kind: 'asr-voice' }
  }
}
import { guardRoute, readJsonBody, redactSecret, sendJson, statusOfBodyError } from './http.ts';
import { LIST_MODELS_TIMEOUT_MS } from './asr-models.ts';

/** 最小当前模型选择面（由 DSH 的 agentDefaultModel 服务提供，peer 不 import）。 */
interface AgentDefaultModelLike {
  currentSelection(): { provider: string; model: string; reasoningEffort?: string }
}

/** LLM 优化流超时（ms）：模型卡住/过慢时不把宿主流挂死。 */
const LLM_STREAM_TIMEOUT_MS = 60_000

/** 优化输入上限（字符）：请求体本身有 256KB 上限，但那允许 25 万字符的「一段语音转写」，
 *  既不可能（说不了那么久）又白烧一次模型调用。 */
const MAX_INPUT_CHARS = 10_000

/** 优化输出上限（字符）：超出截断并在 payload 里标注 truncated，让客户端能提示用户。 */
const MAX_OUTPUT_CHARS = 20_000

/** 收集阶段的上限（4 倍输出上限）：到量就不再累积——跑飞的模型不该把宿主内存堆满。
 *  停手不影响截断判定：收满即已远超输出上限，输出照旧标 truncated。 */
const MAX_OUTPUT_COLLECT = MAX_OUTPUT_CHARS * 4

/** 在途优化上限：每次优化 = 一条 LLM 流（最长 60s），无上限时并发请求会一起占着
 *  provider 配额与宿主内存。超限 503，不读 body。 */
const MAX_INFLIGHT = 4

/** 提示词优化 system prompt（中英双语指令，要求保留语义、去掉口语、结构化）。 */
const OPTIMIZE_SYSTEM = [
  '你是语音输入的提示词优化器。',
  '把用户口语转写的文字整理成清晰、可直接发给 AI 助手的提示词：',
  '- 去掉语气词、重复、口误（如“嗯”“那个”“就是说”）。',
  '- 补齐标点与分段，修正明显口误。',
  '- 保留用户的真实意图与全部关键信息，不添加原文没有的内容。',
  '- 用原文语言输出（中文保持中文，英文保持英文）。',
  '- 只输出整理后的文本，不要解释、不要加引号或前后缀。',
].join('\n')

/** 一个 DSH 已配置模型的条目（给设置页选择器用）。 */
export interface DshModelEntry {
  id: string
  name: string
}

/** 一个 DSH 已配置 provider 及其模型。 */
export interface DshProviderEntry {
  provider: string
  name: string
  models: DshModelEntry[]
}

/** 模型选择目标（来自设置页选择的 DSH 模型，或当前所选）。 */
export interface OptimizeTarget {
  provider: string
  model: string
}

/** 单个 provider 模型枚举的竞速超时：与 asr-models 的抓取超时同源（见该处导出）。 */

/**
 * 给 promise 套整体超时。
 * ctx.llm.listModels 的接口签名没有 AbortSignal（见 dsh-llm 的 LlmService.listModels，
 * 与 LlmAdapter.listModels 一致），无法真正取消底层调用——竞速是唯一手段：超时后
 * 外层立刻 settle，迟到的底层结果经 settled 标志丢弃（不会 unhandled rejection）。
 * 两个分支都 clearTimeout，timer 不泄漏。
 */
function withTimeout<T>(p: Promise<T>, ms: number): Promise<T> {
  return new Promise<T>((resolve, reject) => {
    let settled = false
    const timer = setTimeout(() => {
      if (settled) return
      settled = true
      reject(new Error(`listModels timed out after ${ms}ms`))
    }, ms)
    p.then(
      (v) => { if (settled) return; settled = true; clearTimeout(timer); resolve(v) },
      (e) => { if (settled) return; settled = true; clearTimeout(timer); reject(e) },
    )
  })
}

/** 枚举 DSH 已配置模型（ctx.llm.listProviders + listModels）。 枚举失败/不可用/超时的 provider 给空模型列表（不阻断整体）。 */
export async function enumerateModels(ctx: Context): Promise<DshProviderEntry[]> {
  const providers = ctx.llm.listProviders();
  const results = await Promise.all(providers.map(async (p) => {
    let models: DshModelEntry[] = [];
    try {
      const listed = await withTimeout(Promise.resolve(ctx.llm.listModels(p.id)), LIST_MODELS_TIMEOUT_MS);
      models = listed.map((m) => ({ id: m.id, name: m.name }));
    } catch {
      // 该 provider 不可枚举（含超时）：跳过模型（仍保留 provider 行，便于提示）。
    }
    return { provider: p.id, name: p.name, models };
  }));
  return results;
}

/**
 * 每次调用分配一个新鲜的调用方 session ID。
 *
 * 部分网关（如 opencode-go 的 Console Go 路由）要求请求带 x-opencode-session
 * 才能路由：GenerateOptions.sessionId 存在时 llm-pi-ai 适配器才会把它注入
 * 会话头，缺失时网关直接 400 MissingSessionID（表现为"模型没有返回文本"）。
 * 聊天回路会由 agent-loop 打上真正的 DSH SessionId；插件侧没有会话绑定，
 * 用随机 ID 即可——网关接受任意值（按需自建会话），不带 sessionHeader 的
 * provider（deepseek-official / xiaomi 等）忽略该字段，实测无副作用。
 */
function newCallSessionId(): string {
  return `dsh-asr-voice-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
}

/** 用 DSH 的 LLM 通道重写文本（target 缺省 = 当前所选模型）。 */
async function optimizeWithLlm(ctx: Context, text: string, target?: OptimizeTarget): Promise<string> {
  let selection: OptimizeTarget;
  if (target !== undefined && target.provider !== '' && target.model !== '') {
    selection = target;
  } else {
    const agentDefaultModel = ctx.get('agentDefaultModel') as AgentDefaultModelLike | undefined;
    if (agentDefaultModel === undefined) {
      throw new Error('LLM optimize unavailable: agentDefaultModel service not present');
    }
    const current = agentDefaultModel.currentSelection();
    selection = { provider: current.provider, model: current.model };
  }
  // GenerateOptions.sessionId 是 dsh-brand 名义类型（会话头只随它下发），
  // 插件侧无法 import 该 brand（非直接依赖），调用处做一次断言即可——运行时无校验。
  const options = {
    provider: selection.provider,
    model: selection.model,
    system: OPTIMIZE_SYSTEM,
    sessionId: newCallSessionId(),
    messages: [
      createUserMessage({
        content: [{ type: 'text', text }],
        source: { kind: 'asr-voice' },
      }),
    ],
    temperature: 0.2,
    // 模型卡住/过慢时不把宿主流挂死（客户端 60s 超时后 host 应停止等待）。
    signal: AbortSignal.timeout(LLM_STREAM_TIMEOUT_MS),
  } as unknown as Parameters<typeof ctx.llm.stream>[0];
  // 流式文本累积用数组 + join（避免长响应对每 chunk 反复拼接字符串）；累积有上限。
  const parts: string[] = [];
  let collected = 0;
  // 上游失败的真实原因（错误码/网关响应体）只在 finish 的 failure 里，取出来透出给用户，
  // 否则一律变成笼统的 "model returned no text"（如 400 MissingSessionID 曾被完全吞掉）。
  let finishFailure: string | undefined;
  for await (const chunk of ctx.llm.stream(options)) {
    if (chunk.type === 'text-delta' && collected < MAX_OUTPUT_COLLECT) {
      parts.push(chunk.text);
      collected += chunk.text.length;
    }
    if (chunk.type === 'finish' && (chunk.reason.kind === 'error' || chunk.reason.kind === 'aborted')) {
      finishFailure = chunk.reason.failure.message;
    }
  }
  const output = parts.join('');
  if (finishFailure !== undefined && finishFailure !== '') {
    // 失败原因来自上游网关，可能回显请求材料（含 Authorization）——过脱敏再透出浏览器。
    throw new Error(`LLM optimize failed: ${redactSecret(finishFailure, 240)}`);
  }
  if (output.trim() === '') {
    throw new Error('LLM optimize failed: model returned no text');
  }
  return output.trim();
}

/** 注册 /api/asr-voice/optimize 路由。 请求体：{ text, provider?, model? }——provider/model 须为 DSH 已配置模型； 缺省用当前所选 LLM。
 *  顺序：信任围栏 → 在途上限（超限 503）→ 读 body（形状/长度校验）→ LLM。 */
export function registerOptimizeRoute(
  register: (def: { kind: 'exact'; path: string; handler: (req: IncomingMessage, res: ServerResponse) => Promise<void> | void }) => () => void,
  ctx: Context,
): () => void {
  let inflight = 0
  return register({
    kind: 'exact',
    path: '/api/asr-voice/optimize',
    handler: async (req: IncomingMessage, res: ServerResponse) => {
      const denied = guardRoute(req);
      if (denied !== null) return sendJson(res, denied.status, denied.payload);
      if (inflight >= MAX_INFLIGHT) {
        return sendJson(res, 503, { ok: false, reason: 'too many concurrent requests' });
      }
      inflight += 1;
      try {
        const body = (await readJsonBody(req)) as { text?: unknown; provider?: unknown; model?: unknown } | null;
        // JSON 字面量 null / 非对象（数字、字符串）：此前 `body.text` 直接抛 TypeError，
        // 被下面的 catch 兜成 502「上游故障」——其实是请求体形状不对，归 400。
        if (typeof body !== 'object' || body === null) {
          return sendJson(res, 400, { ok: false, reason: 'invalid JSON body: expected an object' });
        }
        if (typeof body.text !== 'string' || body.text.trim() === '') {
          return sendJson(res, 400, { ok: false, reason: 'missing text' });
        }
        if (body.text.length > MAX_INPUT_CHARS) {
          return sendJson(res, 400, { ok: false, reason: `text too long (${body.text.length} > ${MAX_INPUT_CHARS})` });
        }
        const target = typeof body.provider === 'string' && typeof body.model === 'string'
          ? { provider: body.provider, model: body.model }
          : undefined;
        const optimized = await optimizeWithLlm(ctx, body.text, target);
        // 输出截断（不静默）：payload 带 truncated，客户端据此提示用户「结果被截短了」。
        const truncated = optimized.length > MAX_OUTPUT_CHARS;
        return sendJson(res, 200, {
          ok: true,
          text: truncated ? optimized.slice(0, MAX_OUTPUT_CHARS) : optimized,
          truncated,
        });
      } catch (error) {
        const reason = error instanceof Error ? error.message : String(error);
        // 非法 JSON / 超限 / 超时都是请求侧问题（400/413/408），只有 LLM 通道故障才是 502。
        return sendJson(res, statusOfBodyError(error, 502), { ok: false, reason });
      } finally {
        inflight -= 1;
      }
    },
  });
}

/** 注册 /api/asr-voice/models 路由：枚举 DSH 已配置模型（设置页选择器用）。 */
export function registerModelsRoute(
  register: (def: { kind: 'exact'; path: string; handler: (req: IncomingMessage, res: ServerResponse) => Promise<void> | void }) => () => void,
  ctx: Context,
): () => void {
  return register({
    kind: 'exact',
    path: '/api/asr-voice/models',
    handler: async (req: IncomingMessage, res: ServerResponse) => {
      const denied = guardRoute(req, ['GET']);
      if (denied !== null) return sendJson(res, denied.status, denied.payload);
      try {
        const providers = await enumerateModels(ctx);
        return sendJson(res, 200, { ok: true, providers });
      } catch (error) {
        const reason = error instanceof Error ? error.message : String(error);
        return sendJson(res, 502, { ok: false, reason });
      }
    },
  });
}
