/** dsh-asr-voice — host 半区（组合器）。
 * 职责：
 * - 注册插件配置 namespace `asr-voice`（设置页「语音输入」卡片的权威源）
 * - /api/asr-voice/transcribe —— 云端 ASR 代理（浏览器上传音频，host 转发；支持多供应商）
 * - /api/asr-voice/optimize    —— LLM 提示词优化代理
 * - /api/asr-voice/models      —— 枚举 DSH 已配置模型（优化模型选择器）
 * - /api/asr-voice/asr-models  —— 动态获取某供应商的 ASR 模型（设置页「获取模型」）
 * - /api/asr-voice/stats       —— ASR 用量统计（计费相关，低优先级）
 * - 启动时一次性迁移：settings 里的遗留明文 key → DSH credentials，随后抹掉明文
 * LLM 优化默认走 DSH 当前所选 LLM（ctx.agentDefaultModel + ctx.llm），无需
 * 插件单独配 key。云端 ASR 支持多供应商（asr.cloud.providers + active），但
 * settings 里只有 baseUrl / model / mode 等无密钥元数据：API key 存 DSH
 * credentials（引用名见 src/key-ref.ts），浏览器只经私有 JSON 路由调用，拿不到 key。
 * 纯 Node HTTP + 官方 LLM 通道，无平台专属二进制 → macOS / Windows 双平台。
 */
import type { Context, Volatile } from '@deepseek-ai/cordis';
// Type-only: pulls the @deepseek-ai/cordis Context merge (ctx.webServer).
import type {} from '@deepseek-ai/dsh-host-webserver';
// Type-only: pulls ctx.llm (LlmRuntime).
import type {} from '@deepseek-ai/dsh-llm';
// Type-only: pulls ctx.settings (SettingsProvider) merge for scoped inject.
import type {} from '@deepseek-ai/dsh-settings';
import { ASR_VOICE_SETTINGS_NAMESPACE, type AsrVoiceSettings } from './settings.ts';
import { keyRefFor } from './key-ref.ts';
import { registerTranscribeRoute, resolveApiKey, type CloudAsrConfig } from './transcribe.ts';
import { registerOptimizeRoute, registerModelsRoute } from './optimize.ts';
import { registerAsrModelsRoute, type CloudProviderLike } from './asr-models.ts';
import { createAsrStats, registerStatsRoute } from './stats.ts';
import { RealtimeHost } from './realtime-host.ts';
import { createFakeRealtimeProvider, type RealtimeProvider } from './realtime-provider.ts';
import { createDashscopeRealtimeProvider } from './realtime-dashscope.ts';
import { realtimePresetById, REALTIME_PRESETS } from './presets.ts';
import { registerTtsRoute } from './realtime-tts.ts';

/** Host context slice this plugin consumes (webServer/llm/settings via type merges). */
type AsrVoiceHostContext = Context;

/**
 * DSH 0.1.7 起 apply 收到的配置：schema 顶层 volatile，所以每个字段都是
 * `Volatile<T>` 引用（官方 llm-deepseek `plainOptions()` 同款语义）。
 */
type AsrVoiceHostConfig = {
  [K in keyof AsrVoiceSettings]: AsrVoiceSettings[K] extends object
    ? { [P in keyof AsrVoiceSettings[K]]: Volatile<AsrVoiceSettings[K][P]> }
    : Volatile<AsrVoiceSettings[K]>
};

/**
 * 是否 volatile 引用。
 *
 * 判据与官方一致：cosmokit 的品牌 symbol `cosmokit.volatile.write`（见
 * `vendor/cosmokit/src/volatile.ts` 的 `isVolatile`）。`get` 只作兼容回退——
 * 只用「有 get 方法」会在两个方向咬人：不同 ESM/CJS 副本只带品牌 symbol 时
 * **漏剥**（`plainSettings` 返回带 `get` 的假快照，整棵配置读成 undefined，
 * 无编译错无运行错），以及业务对象带 `get` 时**误剥**一层。
 */
const VOLATILE_BRAND = Symbol.for('cosmokit.volatile.write')

// 内部导出（非插件公共 API）：只为让 node 单测能直连这条判据（test/index-logic.test.mjs
// 的「剥引判据与官方一致」用例）。判据本身不随导出改变。
export function isVolatileRef(value: unknown): value is Volatile<unknown> {
  if (typeof value !== 'object' || value === null) return false
  if (VOLATILE_BRAND in value) return true
  return typeof (value as { get?: unknown }).get === 'function'
}

/**
 * 把 volatile 配置递归解引用成业务侧读的普通快照（每次调用现取最新值）。
 * 嵌套对象（asr.cloud / behavior / realtime.vad…）逐层剥引，叶子是 Volatile。
 */
function plainOf(value: unknown): unknown {
  if (isVolatileRef(value)) return plainOf(value.get())
  if (Array.isArray(value)) return value.map(plainOf)
  if (typeof value === 'object' && value !== null) {
    return Object.fromEntries(Object.entries(value).map(([k, v]) => [k, plainOf(v)]))
  }
  return value
}

/** 业务侧设置快照（深层解引用后的普通对象）。 */
function plainSettings(config: AsrVoiceHostConfig): AsrVoiceSettings {
  return plainOf(config) as AsrVoiceSettings
}

export const name = 'dsh-asr-voice';

/**
 * DSH 0.1.7 profile-backed forms：配置 schema 必须在入口模块**顶层导出**（官方
 * SettingsForms 读 `entry.fiber.runtime.Config`，namespace 取 `entry.options.id`）。
 * schema 本体在 ./settings.ts，这里转置出来；volatile 标记也在那边，勿在此重复。
 */
export { AsrVoiceSettingsSchema as Config, ASR_VOICE_SETTINGS_NAMESPACE } from './settings.ts';

/** 所需 Cordis 服务（服务名，非 entry id）。 */
// settings / agentDefaultModel 不作为硬依赖：settings 用 scoped inject（缺失时仅云端
// ASR 无 key 可用、不影响挂载），agentDefaultModel 在优化路由内 ctx.get 可选读取。
export const inject = ['webServer', 'llm'];

/**
 * 供应商行归一化：settings 深层结构（多供应商/旧单配置）里同一组字段的取值
 * 规则一致（缺省 preset=openai、mode=auto、其余空串），所有读取路径共用
 * 这一个视图，避免四处维护同一份兜底规则。
 * **凭据引用名的派生入口也必须唯一**：`keyRefFor` 只认 preset/name/id 三个字段，
 * 直接拿原始行（可能缺 id/name）派生的结果会与读取路径（先过本视图兜底 id）分叉——
 * 迁移写入的引用名没人读，明文一被抹掉密钥就彻底不可达（见 migrateLegacyKeys）。
 * @param row 供应商原始行（name/id 均可缺省：name 用于显示，id 用于引用派生）。
 * @param idFallback 行缺 id 时的兜底 id。
 * @param modeOverride 显式 mode（undefined = 取行内 mode，缺省 'auto'）。
 */
// 内部导出（非插件公共 API）：纯函数 + 可注入依赖，node 单测直连
// （test/index-logic.test.mjs），不为此搭 Cordis mock 基座。
export function providerView(
  row: { id?: string; preset?: string; name?: string; baseUrl?: string; apiKey?: string; model?: string; mode?: string },
  idFallback: string,
  modeOverride?: string,
): { id: string; preset: string; name: string; baseUrl: string; apiKey: string; model: string; mode: string } {
  return {
    id: row.id || idFallback,
    preset: row.preset ?? 'openai',
    name: row.name ?? '',
    baseUrl: row.baseUrl ?? '',
    apiKey: row.apiKey ?? '',
    model: row.model ?? '',
    mode: modeOverride ?? row.mode ?? 'auto',
  }
}

/** 从 settings 解析当前生效的云端 ASR 供应商（多供应商 active/首个，或旧单配置）。
 * 内部导出：单测直连。 */
export function resolveCloudProvider(v: AsrVoiceSettings | undefined): CloudAsrConfig | undefined {
  if (!v) return undefined
  const cloud = v.asr.cloud
  if (Array.isArray(cloud.providers) && cloud.providers.length > 0) {
    const active = cloud.providers.find((p) => p.id === cloud.active) ?? cloud.providers[0]!
    return providerView(active, 'provider')
  }
  // 旧单配置（v0.1 遗留）
  return providerView({ ...cloud, id: 'legacy' }, 'legacy')
}

/** 读取全部已配置供应商（多供应商列表；旧单配置合成一个 'legacy'）。
 * 内部导出：单测直连。 */
export function listProviders(v: AsrVoiceSettings | undefined): CloudProviderLike[] {
  if (!v) return []
  const cloud = v.asr.cloud
  if (Array.isArray(cloud.providers) && cloud.providers.length > 0) {
    return cloud.providers.map((p) => providerView(p, 'provider'))
  }
  if (cloud.baseUrl) {
    return [providerView({ ...cloud, id: 'legacy' }, 'legacy')]
  }
  return []
}

/** DSH credentials 服务的最小面（可选服务，本插件不把它列为硬依赖）。 */
interface CredentialsLike {
  set(ref: unknown, value: string): Promise<void>
}

/** 一次性迁移：把 settings 里遗留的明文 API key 搬进 DSH credentials，全部搬成功后抹掉明文。
 * 任一条搬不动（凭据服务缺席、该引用被只读来源拒绝）就整批原样留着——抹掉一把无处可寻的
 * key 比留一份本机明文更糟。{@link resolveApiKey} 始终先读 settings，所以未迁移状态下功能
 * 不降级；迁移成功后 settings 里的 key 恒为空，密钥只剩 credentials 一个来源。
 * 内部导出（非插件公共 API）：scope/credentials/log 全部可注入，node 单测直连。
 */
export async function migrateLegacyKeys(
  scope: { get(): AsrVoiceSettings; update(patch: object): Promise<void> },
  credentials: CredentialsLike | undefined,
  log: { warn(message: string): void; info(message: string): void },
): Promise<void> {
  if (credentials === undefined) {
    // 凭据服务缺席 = 一条 key 都搬不走，而它们会继续以明文留在 settings 里。静默返回
    // 会让用户以为「已经搬完了」——这条 warn 是唯一的线索（迁移本身不阻断插件挂载）。
    log.warn('credentials service unavailable: legacy plaintext API keys were not migrated (they remain in plugin settings)')
    return
  }
  // scope.get() 交回来的是深度冻结的解析快照，改之前必须先脱冻。
  const cloud = structuredClone(scope.get().asr.cloud)
  const pending: Array<{ ref: string; key: string }> = []
  for (const row of cloud.providers) {
    const key = (row.apiKey ?? '').trim()
    if (key === '') continue
    // 引用名必须与读取路径（resolveCloudProvider / listProviders → providerView → keyRefFor）
    // 从**同一个**归一化视图派生：先前这里直接用原始行，行缺 id/name 时读取路径兜底成
    // 'provider'、迁移路径兜底成 'CUSTOM'（{id:'', preset:'custom', name:''} 实测：读
    // ASR_VOICE_PROVIDER_API_KEY、写 ASR_VOICE_CUSTOM_API_KEY），明文一被抹掉 key 就再也
    // 没人读得到。派生入口只能有一个。
    pending.push({ ref: keyRefFor(providerView(row, 'provider')), key })
    row.apiKey = ''
  }
  const legacyKey = (cloud.apiKey ?? '').trim()
  if (legacyKey !== '') {
    // 旧单配置的读取路径是 resolveCloudProvider 的 `providerView({ ...cloud, id: 'legacy' }, 'legacy')`，
    // 这里照抄同一个视图（写死其它兜底会分叉）。
    pending.push({ ref: keyRefFor(providerView({ ...cloud, id: 'legacy' }, 'legacy')), key: legacyKey })
  }
  if (pending.length === 0) return
  for (const item of pending) {
    try {
      await credentials.set(item.ref, item.key)
    } catch (error) {
      const reason = error instanceof Error ? error.message : String(error)
      log.warn(`credentials.set(${item.ref}) refused: ${reason}; legacy keys left in place`)
      return
    }
  }
  const patch: Record<string, unknown> = { providers: cloud.providers }
  if (legacyKey !== '') patch.apiKey = ''
  try {
    await scope.update({ asr: { cloud: patch } })
  } catch (error) {
    // 到这儿 key 已经全部写进 credentials、settings 里的明文还在：半数完成态。
    // 只落 warn 用户无法感知，所以把状态两边都点名——下次重启会重试，
    // resolveApiKey 先读 settings 所以功能不降级。
    const reason = error instanceof Error ? error.message : String(error)
    log.warn(
      `keys moved into credentials but clearing plugin settings failed: ${reason};`
      + ' the plaintext keys remain in settings and will be retried on next start'
      + ' (keys stay readable from settings meanwhile, so ASR keeps working)',
    )
    return
  }
  log.info(`moved ${pending.length} API key(s) from plugin settings into DSH credentials`)
}

/** 实时 provider 工厂（I5）：按 `realtime.provider` 设置分派。
 * '' / 'builtin' → 内置假 provider（I3/I4 开发态，不花配额）；
 * 预置 id（如 'dashscope-realtime'）→ 真云端 provider，凭据复用 DSH credentials
 * （keyPreset 指回 CLOUD_PRESETS 预置，`keyRefFor` 派生成 `<PRESET>_API_KEY`，
 * 配过同名 LLM 的用户天然命中同一把 key）。无 key 时 connect 抛错，让会话路由
 * 502 带原因，客户端可见「provider-unreachable」而不是静默降级。
 * 未知 id 同样抛错（不回落假 provider）——见下方注释。
 */
function createRealtimeProvider(
  ctx: AsrVoiceHostContext,
  getSettings: () => AsrVoiceSettings | undefined,
): RealtimeProvider {
  const pid = getSettings()?.realtime.provider ?? ''
  if (pid === '' || pid === 'builtin') return createFakeRealtimeProvider()
  const preset = realtimePresetById(pid)
  if (preset === undefined) {
    // 未知 id **不静默回落到内置模拟**：那会让用户以为在用云端，实际拿到「模拟转写·第N段」
    // 并被当成真实转写提交。抛错 → 会话路由 502 带原因 → 客户端提示云端通道不可用。
    // 只在手改配置/预置被改名时才会走到（设置页的下拉只列 REALTIME_PRESETS）。
    return {
      connect: async () => {
        throw new Error(
          `unknown realtime provider "${pid}" — expected '' / 'builtin' or one of: ${REALTIME_PRESETS.map((p) => p.id).join(', ')}`,
        )
      },
    }
  }
  return {
    connect: async () => {
      const apiKey = await resolveApiKey(ctx, {
        id: preset.id,
        preset: preset.keyPreset,
        name: preset.label,
        baseUrl: '',
        apiKey: '',
        model: preset.defaultModel,
        mode: 'chat',
      })
      if (apiKey === '') {
        throw new Error(
          `realtime provider ${pid}: no API key — set the credential ${keyRefFor({ preset: preset.keyPreset, name: preset.label, id: preset.id })} in DSH (a same-named LLM key is reused automatically)`,
        )
      }
      return createDashscopeRealtimeProvider({ apiKey, model: preset.defaultModel, wssUrl: preset.wssUrl }).connect()
    },
  }
}

export function apply(ctx: AsrVoiceHostContext, config: AsrVoiceHostConfig): void {
  // DSH 0.1.7 profile-backed forms：配置由 Cordis 作为函数插件第二参注入
  // （schema 是本模块顶层导出的 Config）。volatile 字段每次显式 `.get()` 解引用，
  // 热改后同一份闭包拿到的就是最新值，无需 scope 轮询或重挂插件。
  const settingsScope: { get(): AsrVoiceSettings; update(patch: object): Promise<void> } = {
    get: () => plainSettings(config),
    update: (patch) => ctx.settings.update(ASR_VOICE_SETTINGS_NAMESPACE, patch),
  }
  // 遗留明文 key → credentials：启动时跑一次，迁移完成后每次都是空转早退。
  const logger = ctx.logger('asr-voice')
  ctx.effect(() => {
    const migrating = migrateLegacyKeys(settingsScope, ctx.get('credentials') as CredentialsLike | undefined, logger)
      .catch((error: unknown) => { logger.warn(`legacy key migration stopped: ${error instanceof Error ? error.message : String(error)}`) })
    return async () => { await migrating }
  }, 'asr-voice: migrate legacy api keys')

  const getCloudConfig = (): CloudAsrConfig => {
    const cfg = resolveCloudProvider(settingsScope?.get());
    return cfg ?? { id: '', preset: 'openai', name: '', baseUrl: '', apiKey: '', model: '', mode: 'auto' };
  };
  const getProviders = (): CloudProviderLike[] => listProviders(settingsScope?.get());
  const stats = createAsrStats();

  // 路由随 fiber 生命周期注册/回收。
  ctx.effect(() => registerTranscribeRoute(
    (def) => ctx.webServer.register(def),
    getCloudConfig,
    ctx,
    (text, providerId) => stats.record(text, providerId),
  ), 'asr-voice: transcribe route');
  ctx.effect(() => registerOptimizeRoute((def) => ctx.webServer.register(def), ctx), 'asr-voice: optimize route');
  ctx.effect(() => registerModelsRoute((def) => ctx.webServer.register(def), ctx), 'asr-voice: models route');
  ctx.effect(() => registerAsrModelsRoute((def) => ctx.webServer.register(def), getProviders, ctx), 'asr-voice: asr-models route');
  ctx.effect(() => registerStatsRoute((def) => ctx.webServer.register(def), () => stats.snapshot()), 'asr-voice: stats route');

  // 云端 TTS（I6）：文本 → 私有路由 → qwen3-tts-flash-realtime，浏览器不持 key。
  // 凭据固定复用 DASHSCOPE_API_KEY（getTtsConfig 只喂 preset=dashscope 的空壳配置，
  // resolveApiKey 按 keyRefFor 派生引用名，配过同名 LLM 的用户天然命中）。
  ctx.effect(() => registerTtsRoute(
    (def) => ctx.webServer.register(def),
    () => ({ id: 'tts', preset: 'dashscope', name: '', baseUrl: '', apiKey: '', model: '', mode: 'chat' }),
    ctx,
  ), 'asr-voice: tts route');

  // 实时转写通道（I3）：会话注册表 + SSE 下行 + RealtimeProvider 接缝。
  // I3/I4 阶段 host 用假 provider 驱动整条管道；I5 按 settings `realtime.provider`
  // 分派到真云端（qwen3-asr-flash-realtime）或内置模拟——接缝与路由一行不改。
  ctx.effect(() => {
    const host = new RealtimeHost({
      createProvider: () => createRealtimeProvider(ctx, () => settingsScope?.get()).connect(),
      // 绝对 TTL 现读用户设置（settings 热改立刻对新会话生效）；settings 不可用时退回
      // 与 schema 默认值一致的 10 分钟——host 侧的兜底不能依赖客户端自觉。
      maxSessionMs: () => settingsScope?.get()?.realtime.maxSessionMs ?? 600_000,
    });
    const disposeRoutes = host.registerRoutes((def) => ctx.webServer.register(def));
    return () => {
      disposeRoutes();
      // 会话清理归 fiber（在注销路由之外）：卸载/热重载时逐个拆掉活动会话——
      // SSE 心跳、idle timer、provider WS 全部随 closeSession 释放，不泄漏到进程结束。
      host.dispose();
    };
  }, 'asr-voice: realtime routes');
}
