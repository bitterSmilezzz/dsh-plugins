/** dsh-asr-voice — client 语音按钮（conversation.input.right 工具行）。
 * **一个按钮，两个动作**：点 = 录音转写，长按 = 语音对话。
 * 曾经是并排两个按钮（麦克风 + 气泡），交互面冗余、还占输入栏宽度；合并后
 * 用「点/长按」这对手势区分，两条链路各自仍是完整闭环：
 * - 点：录音（浏览器 Web Speech 实时 / 云端 MediaRecorder）→ 停止 → 转写文本
 *   → 提示词优化（heuristic 即时 / llm 预览卡）→ 填入草稿（inputActions.setDraft），
 *   可选自动发送（inputActions.submit）。
 * - 长按：进入实时语音对话（voice-chat.tsx），再点结束或打断。
 * 两条链路共用同一个输入设备，所以互斥守卫成对出现：录音侧在 begin() 与长按许可里
 * 读 chatActiveRef，对话侧经 canStart 读麦克风状态。
 * 动效（microanimations 原则：反馈/定向/愉悦，克制）：
 * - 录音：多层呼吸光环（back.out 缓动、错开延迟、非机械）+ 实时频谱条
 * （cloud 真实 RMS / browser 模拟能量，CSS 变量驱动）
 * - 状态提示条：滑入 + 呼吸点（recording）/ 转圈（transcribing/optimizing）
 * - 按钮：hover 微缩放、active 按压缩放；长按可用时右上角一颗静态小点
 * 独立契约：本组件只依赖官方 slot 标准 kit（inputActions / session / input），
 * 不依赖任何第三方插件；样式 data 标签与命名空间唯一。
 */
import * as react from 'react'
// Type-only: pulls the ui-conversation SlotMap merge (input seats + standard kit).
import type {} from '@deepseek-ai/dsh-client-ui-conversation/client'
import { cloudConfigured, config, recordBehavior } from './config.ts'
import { appendDraftText } from './draft.ts'
import { resolveEngine, shouldFallbackToCloud } from './engine.ts'
import { heuristicOptimize, llmOptimize } from './optimize.ts'
import { createVoiceRecorder, isWebSpeechSupported, type VoiceRecorder } from './recorder.ts'
import { fromTo } from './animate.ts'
import { ChatIcon, MicIcon, RecDot, SpectrumBars, Spinner } from './icons.tsx'
import { DEFAULT_LONG_PRESS_MS, createLongPressGate } from './long-press.ts'
import { routeButtonPress, type MicPhase } from './button-route.ts'
import { useVoiceChat, type ReplyBlock } from './voice-chat.tsx'
import { systemDict } from './locales.ts'
import type { LocaleT } from './locales.ts'

/** 输入动作最小面（来自官方 standard kit 的 inputActions prop）。 */
interface InputActionsLike {
  setDraft(text: string): void
  submit(): void
}

/** 组件收到的 owner share + standard kit 最小面（结构类型，参照官方契约）。
 * 一个按钮同时驱动两条链路：录音转写（本文件）与实时语音对话（voice-chat.tsx），
 * 所以 owner share 要同时满足两边——`phase`/`blank` 归录音用，
 * `running`/`partial` 归对话用（跟读流式回复）。 */
export interface VoiceButtonProps {
  sessionId?: string
  input?: { draft?: string; phase?: string }
  session?: {
    blank?: boolean
    composerPhase?: string
    running?: boolean
    partial?: { blocks?: readonly ReplyBlock[] } | null
  }
  inputActions?: InputActionsLike
  /** 取消当前回合：由 host 半区经 slot inject 注入（组件拿不到 ctx）。 */
  cancelTurn?: (sessionId: string) => void
  /** 本地化翻译函数（由 slot inject 注入）。 */
  t: LocaleT
}

/** 组件内部状态机（与 button-route.ts 的 MicPhase 同源，单点定义防漂移）。 */
type VoiceState = MicPhase

/** 录音实例的最小面（全局控制器与快捷键只经它驱动当前可见会话）。 */
interface VoiceControllerInstance {
  toggle(): void
  /** 按住说话的松键：只在确实录音时才收尾（见 releaseHold）。 */
  releaseHold(): void
  isRecording(): boolean
  isBusy(): boolean
}

/** 全局录音控制器：只驱动「最后挂载」的实例（当前可见会话）。 */
export const voiceController = {
  toggle: (): void => { current?.toggle() },
  isRecording: (): boolean => current?.isRecording() ?? false,
  /** 是否处于 busy（录音 / 识别 / 优化）——快捷键据此区分"打断"与"开始"。 */
  isBusy: (): boolean => current?.isBusy() ?? false,
  /** 按住说话的松键。**不能**复用 toggle()：录音可能已经自己结束了
   *  （静音自动停止 / no-speech / 到达时长上限），此时 toggle 落在 transcribing
   *  会 cancel 掉在途转写（用户刚口述的文本直接消失），落在 idle 会重新开录
   *  （键已松开，麦克风一直录到上限）。松键的语义只有一个：收尾正在进行的录音。 */
  releaseHold: (): void => { current?.releaseHold() },
  mount(instance: VoiceControllerInstance): () => void {
    current = instance
    return () => { if (current === instance) current = undefined }
  },
}
let current: VoiceControllerInstance | undefined

/** 录音按钮 + 状态提示条 + 预览卡。 @param props - slot 注入的 owner share + 标准 kit + 翻译函数。 */
export function VoiceButton(props: VoiceButtonProps): react.ReactElement {
  const { inputActions, t } = props
  // 只有拿不到标准 kit 的 inputActions（无可用会话/惰性输入栏）才禁用。
  // 注意：不按 session.blank 禁用——新版 DSH 里空白会话（hero 新对话）的输入栏
  // 完全可用（可打字/发送首条消息），语音输入应同样可用；实测 blank 时点麦克风
  // 无任何响应（disabled 吞掉点击），玩家以为是坏按钮。
  const disabled = !inputActions
  const [state, setState] = react.useState<VoiceState>('idle')
  const [error, setError] = react.useState<string | null>(null)
  const [notice, setNotice] = react.useState<string | null>(null)
  const [interim, setInterim] = react.useState<string>('')
  const [preview, setPreview] = react.useState<{ original: string; optimized: string } | null>(null)
  // 快速路径标志：optimizing 状态下草稿已填入（区别于预览卡路径的等待）。
  const [optimizingDraft, setOptimizingDraft] = react.useState(false)

  const wrapRef = react.useRef<HTMLSpanElement | null>(null)
  const hintRef = react.useRef<HTMLSpanElement | null>(null)
  const spectrumRef = react.useRef<HTMLSpanElement | null>(null)
  // 预览卡的焦点管理：打开时把焦点交给「确认」按钮（键盘用户不必自己 Tab 找过来），
  // 关闭（确认/取消/Esc）后还给麦克风按钮——否则焦点落在被卸载的节点上，退回 body。
  const micButtonRef = react.useRef<HTMLButtonElement | null>(null)
  const previewConfirmRef = react.useRef<HTMLButtonElement | null>(null)
  const previewDescId = react.useId()
  // 频谱电平上次写入值：rAF 每帧都会回调，只在变化超过阈值时写 CSS 变量，
  // 避免无谓的样式传播（波动是连续的，0.01 步进视觉无差）。
  const levelRef = react.useRef(-1)
  const recorderRef = react.useRef<VoiceRecorder | null>(null)
  const optimizeControllerRef = react.useRef<AbortController | null>(null)
  const stateRef = react.useRef<VoiceState>('idle')
  stateRef.current = state
  // 对话是否正在进行。两条链路共用同一个输入设备，谁先占了另一个就不能再抢：
  // 录音侧在 begin() 与长按许可里都读它（对话侧的对称守卫见 voice-chat.tsx 的 canStart）。
  const chatActiveRef = react.useRef(false)
  // 长按要用的两样东西在下面 useVoiceChat 之后才有值，先留 ref 转发：
  // 长按回调活在事件里，不能用挂载那一帧的闭包。
  const chatEnabledRef = react.useRef(false)
  const chatToggleRef = react.useRef<() => void>(() => {})
  // 长按手势：点 = 转写，长按 = 对话。判定是纯逻辑（long-press.ts），这里只管接线。
  const longPressRef = react.useRef<ReturnType<typeof createLongPressGate> | null>(null)
  if (longPressRef.current === null) {
    longPressRef.current = createLongPressGate({
      thresholdMs: DEFAULT_LONG_PRESS_MS,
      // 麦克风正忙（录音/识别/优化）时不认长按：此时按住只该是「点」的拖长，
      // 用户想的是停止录音，不该顺手把对话也开起来。
      isLongPressAllowed: () => chatEnabledRef.current && stateRef.current === 'idle',
      onLongPress: () => { chatToggleRef.current() },
    })
  }
  // 打断标志：cancel() 置位后，迟到的 onDone/onFail/优化结果一律丢弃。
  const cancelledRef = react.useRef(false)
  // 会话代际：begin() 递增，异步回调捕获自己的代际；cancel→立即 begin 时
  // 旧 promise 的 finally 用代际差异识别并丢弃，避免改写新会话状态。
  const generationRef = react.useRef(0)
  // 草稿最新值（props 异步回写）与本次填入的值——后台优化替换时防覆盖用户编辑。
  const draftRef = react.useRef<string>('')
  const insertedRef = react.useRef<string | null>(null)
  react.useEffect(() => {
    const next = props.input?.draft ?? ''
    // 草稿离开插件的掌控（用户编辑/发送清空）→ 后台优化立即作废：
    // 优化走 ctx.llm.stream（与 agent 回合同一条 LLM 通道），发送后仍挂着会让
    // 新回合的 LLM 请求排队（发送后卡顿的直接来源），且结果对已发送草稿毫无价值。
    if (insertedRef.current !== null && next !== insertedRef.current && optimizeControllerRef.current !== null) {
      optimizeControllerRef.current.abort()
      optimizeControllerRef.current = null
    }
    draftRef.current = next
  }, [props.input?.draft])
  // 错误/提示自动消散（6s），避免状态条永久悬挂；也可点 × 手动关闭。
  react.useEffect(() => {
    if (error === null && notice === null) return
    const timer = setTimeout(() => {
      setError(null)
      setNotice(null)
    }, 6000)
    return () => clearTimeout(timer)
  }, [error, notice])
  const dismissHint = (): void => {
    setError(null)
    setNotice(null)
  }
  // 预览卡出现即接管焦点（见 micButtonRef 的说明）。
  react.useEffect(() => {
    if (preview !== null) previewConfirmRef.current?.focus()
  }, [preview])

  // 挂载/卸载：注册到全局控制器（快捷键驱动当前实例）。
  // instance 是 useMemo([]) 冻结产物，若直接捕获首帧 begin/finish/cancel，
  // 其闭包里的 inputActions/props.input 也是首帧快照——会话就绪前挂载时，
  // 快捷键路径 finalize 会拿不到 inputActions 静默丢字。经 ref 每渲染转发最新闭包。
  const handlersRef = react.useRef<{ begin(): Promise<void>; finish(): void; cancel(): void }>({
    begin: async () => {}, finish: () => {}, cancel: () => {},
  })
  const instance = react.useMemo(() => ({
    toggle: () => {
      if (stateRef.current === 'idle') { void handlersRef.current.begin() } else if (stateRef.current === 'recording') { void handlersRef.current.finish() } else { handlersRef.current.cancel() }
    },
    // 松键只收尾「正在录音」这一种状态，其余一律不动（见 voiceController.releaseHold）。
    releaseHold: () => { if (stateRef.current === 'recording') void handlersRef.current.finish() },
    isRecording: () => stateRef.current === 'recording',
    isBusy: () => stateRef.current !== 'idle',
  }), [])
  react.useEffect(() => voiceController.mount(instance), [instance])

  const setPhase = (next: VoiceState): void => {
    // 离开 recording 就停光环：静音/超时自动停止（onDone 直达）、录音中出错
    // （onFail）与 no-speech 都不经 finish/cancel，漏停会让 repeat:Infinity 的
    // 波纹 rAF 循环空转到卸载，idle 按钮上残留红色脉冲环。
    if (stateRef.current === 'recording' && next !== 'recording') stopWave()
    stateRef.current = next
    setState(next)
  }

  const showError = (code: string, detail?: string): void => {
    // 静音守卫：录音整段静音（麦克风未采到声）→ 明确提示 + 输入设备名，误打误撞的 ASR 报错。
    if (code === 'transcribe' && detail?.startsWith('no-sound')) {
      const label = detail.slice('no-sound'.length).replace(/^:/, '')
      const shown = label.length > 80 ? `${label.slice(0, 80)}…` : label
      setError(`${t('errNoSound')}${shown ? `（${shown}）` : ''}`)
      setNotice(null)
      setPhase('idle')
      return
    }
    // 错误码 → 文案用 switch 而非嵌套三元：这条链已到 8 个分支，深层三元改一处极易
    // 错位到相邻分支（本仓刚修过「云端引擎却提示不支持 Web Speech」那类反向误导）。
    const msg = ((): string => {
      switch (code) {
        case 'mic-denied':
        case 'no-mic':
          return t('errNoMic')
        case 'recorder-start-failed':
        case 'recorder-unsupported':
          return t('errRecorderStart')
        case 'no-speech-support':
          return t('errNoSpeechSupport')
        case 'network':
          return t('errWebSpeechNetwork')
        case 'cloud-not-configured':
          return t('errCloudNotConfigured')
        case 'optimize':
          return `${t('errOptimize')}${detail ? `: ${detail}` : ''}`
        default:
          return `${t('errTranscribe')}${detail ? `: ${detail}` : ''}`
      }
    })()
    setError(msg)
    setNotice(null)
    setPhase('idle')
  }

  /** 启动指定引擎的录音（云端自动兜底：auto 模式下浏览器失败 → 云端重试一次）。 */
  const startWithEngine = (engine: 'browser' | 'cloud'): void => {
    let recorder: VoiceRecorder
    // 本会话代际：recorder 级 cancelled 标志只防 abort，防不了「停止→立刻重开」
    // 的会话替换——旧 recorder 的迟到回调（onDone/onFail/onState/onInterim）必须
    // 用代际差异丢弃，否则会 null 掉新会话的 recorderRef 或污染新草稿。
    const myGen = generationRef.current
    const stale = (): boolean => cancelledRef.current || generationRef.current !== myGen
    try {
      recorder = createVoiceRecorder(engine, config.language, (code) => {
        if (stale()) return
        if (code === 'no-speech') {
          // 无语音：当作正常结束，给一个轻提示（非错误）。
          setPhase('idle')
          setError(null)
          setNotice(t('noSpeechDetected'))
          return
        }
        // auto 兜底：浏览器不可用（网络/权限被浏览器 Web Speech 拒）且云端已配置 → 重试云端。
        const recoverable = code === 'network' || code === 'not-allowed' || code === 'service-not-allowed' || code === 'no-speech-support'
        if (shouldFallbackToCloud(engine, config.asr.provider, cloudConfigured(), recoverable)) {
          setNotice(t('fallbackToCloud'))
          startWithEngine('cloud')
          return
        }
        showError(code)
      }, recordBehavior())
    } catch {
      if (shouldFallbackToCloud(engine, config.asr.provider, cloudConfigured())) {
        setNotice(t('fallbackToCloud'))
        startWithEngine('cloud')
        return
      }
      showError('no-speech-support')
      return
    }
    recorderRef.current = recorder
    levelRef.current = -1
    recorder.onInterim = (text) => { if (!stale()) setInterim(text) }
    recorder.onState = (s) => { if (s === 'transcribing' && !stale()) setPhase('transcribing') }
    recorder.onLevel = (rms) => {
      // 频谱条：CSS 变量驱动柱高（避免每帧 React 渲染）。只在与上次写入
      // 差 ≥0.01 时更新（rAF 每帧回调，连续波动微小变化不触发样式传播）。
      const was = levelRef.current
      if (spectrumRef.current && Math.abs(rms - was) >= 0.01) {
        levelRef.current = rms
        spectrumRef.current.style.setProperty('--level', rms.toFixed(2))
      }
    }
    // 结果统一经 onDone/onFail 送达（手动 / 静音自动停止 / 超时自动停止三条路径收敛），
    // 由 handleTranscribed 消费文本、showTranscribeError 消费错误。
    recorder.onDone = (text) => { if (!stale()) handleTranscribed(text) }
    recorder.onFail = (error) => { if (!stale()) showTranscribeError(error) }
    setPhase('recording')
    startWave()
    recorder.start()
  }

  const begin = async (): Promise<void> => {
    // 对话正占着麦克风：录音键（尤其快捷键那条路）不许抢设备。
    // 按钮点击本来就会被路由到对话分支，这里是给快捷键兜底。
    if (chatActiveRef.current) return
    setError(null)
    setNotice(null)
    setInterim('')
    setOptimizingDraft(false)
    // 上一段 preview 未确认就开新录音：旧预览确认会以旧文本覆盖新会话草稿，先清掉。
    setPreview(null)
    cancelledRef.current = false
    // 新会话代际：让旧异步回调（优化/迟到结果）用自己的代际差异识别并丢弃。
    generationRef.current += 1
    optimizeControllerRef.current = new AbortController()
    // 引擎决策是纯函数（src/client/engine.ts）：入参配置三态 + 两个可用性标志，出参决定。
    const engine = resolveEngine(config.asr.provider, isWebSpeechSupported(), cloudConfigured())
    if (engine === 'cloud' && !cloudConfigured()) {
      showError('cloud-not-configured')
      return
    }
    if (engine === 'browser' && !isWebSpeechSupported()) {
      showError('no-speech-support')
      return
    }
    startWithEngine(engine)
  }

  /** 转写错误统一入口（onFail）：取消后到达的错误一律丢弃。 */
  const showTranscribeError = (error: unknown): void => {
    if (cancelledRef.current) return
    recorderRef.current = null
    showError('transcribe', String(error instanceof Error ? error.message : error))
  }

/** 转写完成统一入口（onDone）：默认快速路径（preview=false）——ASR 文本返回后 立即把清洗版填入草稿，LLM 优化在后台跑；preview / autoSend 走等优化路径。 */
  const handleTranscribed = (text: string): void => {
    if (cancelledRef.current) return
    const myGen = generationRef.current
    recorderRef.current = null
    const cleaned = text.trim()
    if (cleaned === '') { setPhase('idle'); return }

    const mode = config.optimize.mode
    if (mode === 'llm') {
      // 文本本来就干净（无语气词/标点问题）→ 跳过 LLM 优化，直接走填入/发送流程。
      const clean = heuristicOptimize(cleaned)
      // autoSend 保持原流程（说完即发，用优化后文本）；preview = 预览卡确认。
      if (config.behavior.autoSend || config.optimize.preview) {
        if (clean === cleaned) {
          finalize(cleaned)
          return
        }
        setPhase('optimizing')
        void llmOptimize(cleaned, {
          provider: config.optimize.llm.provider,
          model: config.optimize.llm.model,
        }, optimizeControllerRef.current?.signal)
          .then((optimized) => {
            if (cancelledRef.current || generationRef.current !== myGen) return
            if (config.optimize.preview) {
              setPreview({ original: cleaned, optimized })
              setPhase('idle')
            } else {
              finalize(optimized)
            }
          })
          .catch((error: unknown) => {
            if (cancelledRef.current || generationRef.current !== myGen) return
            showError('optimize', String(error instanceof Error ? error.message : error))
          })
        return
      }
      // 快速路径（默认）：立即填入清洗版，优化后台替换。
      const fast = clean || cleaned
      insertedRef.current = finalize(fast)
      setOptimizingDraft(true)
      setPhase('optimizing')
      void runBackgroundOptimize(cleaned)
      return
    }
    finalize(heuristicOptimize(cleaned))
  }

/** 快速路径（preview=false 默认）：ASR 文本返回后立即把清洗版填入草稿， LLM 优化在后台跑，完成后仅在用户未编辑草稿时替换。 */
  const runBackgroundOptimize = async (raw: string): Promise<void> => {
    const myGen = generationRef.current
    try {
      const target = {
        provider: config.optimize.llm.provider,
        model: config.optimize.llm.model,
      }
      const optimized = await llmOptimize(raw, target, optimizeControllerRef.current?.signal)
      // 防覆盖：仅当草稿仍是我们填入的文本时才替换（用户已编辑则保留编辑）。
      if (cancelledRef.current || generationRef.current !== myGen) return
      if (draftRef.current === insertedRef.current && inputActions !== undefined) {
        inputActions.setDraft(optimized)
      }
    } catch {
      // 后台优化失败不打断用户：草稿已可用，仅轻提示（6s 后自动消散，可点 × 关闭）。
      // 取消→立刻重开时 cancelledRef 已重置，须连同会话代际一起判定，防旧会话假失败提示串台。
      // 发送/编辑触发的主动放弃（abort 已把 optimizeControllerRef 置 null）同样不算失败。
      if (cancelledRef.current || generationRef.current !== myGen) return
      if (optimizeControllerRef.current === null) return
      setNotice(t('optimizeFailedKeep'))
    } finally {
      // 打断（cancel）后旧 promise 的 finally 不得改写新会话状态：
      // cancel → 立即 begin 时 cancelledRef 已重置，若直接 setPhase('idle')
      // 会把新录音打回 idle。用会话代际标志（toast 由 begin 递增)区分。
      if (cancelledRef.current || generationRef.current !== myGen) return
      insertedRef.current = null
      setOptimizingDraft(false)
      setPhase('idle')
    }
  }

  /** 手动停止：结束录音并进入识别（结果经 onDone 送达）。 */
  const finish = (): void => {
    const recorder = recorderRef.current
    if (!recorder) { setPhase('idle'); return }
    stopWave()
    setNotice(null)
    setPhase('transcribing')
    void recorder.stop().catch(() => { /* 错误经 onFail 送达 */ })
  }

  /** 打断：中止录音 / 转写 / 优化，丢弃一切迟到结果，回到 idle。 */
  const cancel = (): void => {
    if (cancelledRef.current && stateRef.current === 'idle') return
    cancelledRef.current = true
    const recorder = recorderRef.current
    recorderRef.current = null
    optimizeControllerRef.current?.abort()
    optimizeControllerRef.current = null
    if (recorder) recorder.abort()
    stopWave()
    setInterim('')
    insertedRef.current = null
    setOptimizingDraft(false)
    setPreview(null)
    setNotice(null)
    setError(null)
    setPhase('idle')
  }

  /** 把最终文本填入草稿（完整替换 / 末尾追加）+ 可选剪贴板。
   *  返回实际写入草稿的字符串（append 模式下 = existing + sep + text）。 */
  const finalize = (text: string): string => {
    if (text === '') { setPhase('idle'); return text }
    if (inputActions) {
      if (config.behavior.textMode === 'append') {
        // draftRef 是草稿的权威镜像（effect 同步 props 异步回写）；props.input?.draft
        // 是本渲染帧快照，录音期间的编辑会读不到，append 会覆盖丢字。
        // 分隔决策在共享纯函数 appendDraftText（src/client/draft.ts，与语音对话按钮同源）。
        text = appendDraftText(draftRef.current, text)
      }
      inputActions.setDraft(text)
      if (config.behavior.autoSend) inputActions.submit()
    }
    if (config.behavior.copyToClipboard) {
      try {
        const writing = navigator.clipboard?.writeText(text)
        // 失败要说话：Safari 在非用户激活上下文（识别结果是异步回调）里会拒绝写入，
        // 而该开关默认开——静默失败会让用户以为已经复制成功。
        if (writing !== undefined) void writing.catch(() => { setNotice(t('copyFailed')) })
      } catch {
        setNotice(t('copyFailed'))
      }
    }
    setPhase('idle')
    return text
  }
  // 最新闭包转发的挂载点：所有 handler 定义完毕后更新，供冻结的 instance 调用。
  handlersRef.current = { begin, finish, cancel }

  /** 关闭预览卡（确认 / 取消 / Esc 共用）：焦点还给麦克风按钮。 */
  const closePreview = (): void => {
    setPreview(null)
    micButtonRef.current?.focus()
  }
  const onConfirm = (): void => {
    if (preview) finalize(preview.optimized)
    closePreview()
  }

  // ── 呼吸光环（back.out 缓动 + 错开延迟 + 变化幅度，非机械同步） ──
  // 保存无限循环补间的 handle，stop 时 kill 掉——否则 repeat:Infinity 的 rAF 循环
  // 永不停（stopWave 只改内联样式，下一帧又被动画覆盖回去，红色波纹残留）。
  const waveHandlesRef = react.useRef<Array<{ kill(): void }>>([])
  const startWave = (): void => {
    const wrap = wrapRef.current
    if (!wrap) return
    stopWave()
    // 系统 reduced-motion：GSAP 呼吸环是内联样式驱动，CSS media query 管不到，
    // 命中时跳过无限循环动画，只画静态第一帧（半透明外圈）。
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      wrap.querySelectorAll<HTMLElement>('.dshav-wave-ring').forEach((ring) => {
        ring.style.opacity = '0.5'
        ring.style.transform = 'scale(0.72)'
      })
      return
    }
    wrap.querySelectorAll<HTMLElement>('.dshav-wave-ring').forEach((ring, i) => {
      ring.style.opacity = '0.5'
      const spread = 1.9 + (i % 2) * 0.35
      const duration = 1.35 + (i % 2) * 0.2
      const handle = fromTo(ring, { scale: 0.72, opacity: 0.5 }, {
        scale: spread,
        opacity: 0,
        duration,
        delay: i * 0.24,
        ease: 'back.out',
        repeat: Infinity,
      })
      waveHandlesRef.current.push(handle)
    })
  }
  const stopWave = (): void => {
    for (const handle of waveHandlesRef.current) {
      try { handle.kill() } catch { /* noop */ }
    }
    waveHandlesRef.current = []
    const wrap = wrapRef.current
    if (!wrap) return
    wrap.querySelectorAll<HTMLElement>('.dshav-wave-ring').forEach((ring) => {
      ring.style.opacity = '0'
      ring.style.transform = ''
    })
  }

  // 卸载清理：停止录音 + 停止波纹 + 中止在途优化（防对已卸载会话 setDraft）。
  react.useEffect(() => () => {
    stopWave()
    recorderRef.current?.abort()
    optimizeControllerRef.current?.abort()
  }, [])

  // ── 语音对话（同一按钮的另一半能力） ────────────────────────────────
  // 对话的状态机、引擎、播报都在 voice-chat.tsx；这里只取它需要的那几样：
  // 图标/标题/点击动作，以及它自己的状态提示条（放进同一个 wrap 才定位得准）。
  const chat = useVoiceChat({
    sessionId: props.sessionId,
    session: props.session,
    input: props.input,
    inputActions,
    cancelTurn: props.cancelTurn,
    // 录音链路占着麦克风时不给开对话：两边抓的是同一个输入设备。
    canStart: () => stateRef.current === 'idle',
    t,
  })
  chatActiveRef.current = chat.active
  chatEnabledRef.current = chat.enabled
  chatToggleRef.current = chat.toggle

  /** 点按钮：对话中归对话，否则归录音。仲裁本身是纯函数（button-route.ts）。 */
  const onButtonClick = (): void => {
    const action = routeButtonPress({
      // 长按刚触发过：浏览器照样会补一个 click，读一次就复位。
      longPress: longPressRef.current?.shouldSuppressClick() === true,
      chatActive: chat.active,
      micPhase: state,
    })
    if (action === 'none') return
    if (action === 'chat') { chat.toggle(); return }
    if (action === 'begin') { void begin(); return }
    if (action === 'finish') { void finish(); return }
    cancel()
  }
  // 长按用指针捕获：手指/鼠标移出按钮后 pointerup 仍回到按钮，不会漏掉 release。
  const onPointerDown = (e: react.PointerEvent<HTMLButtonElement>): void => {
    // 多指同时按下时只认主指针（第二个指针不该重启计时）。
    if (!e.isPrimary) return
    try { e.currentTarget.setPointerCapture(e.pointerId) } catch { /* 指针已失效：退化成普通点击 */ }
    longPressRef.current?.press()
  }
  const onPointerUp = (): void => { longPressRef.current?.release() }
  // pointercancel（浏览器接管手势）与 lostpointercapture（捕获意外释放）都要收摊，
  // 否则 pressed 卡在 true，下一次 press 会被自己忽略掉。
  const onPointerAbort = (): void => { longPressRef.current?.cancel() }

  const busy = state !== 'idle'
  // 悬停提示按系统语言（与 DSH 界面语言解耦），aria-label 按**界面语言**——
  // 屏幕阅读器按界面语言朗读，混用会读出「英文按钮名 + 中文状态」这类错配。
  const sys = systemDict()
  // 对话进行中时按钮的语义整个归对话；空闲时提示「长按可对话」，否则用户没处知道。
  const title = chat.active
    ? chat.title
    : busy
      ? state === 'recording' ? sys.recordingTitle : state === 'transcribing' ? sys.transcribingTitle : sys.optimizingTitle
      : chat.enabled ? sys.micTitleHoldChat : sys.micTitle
  const ariaLabel = chat.active
    ? chat.ariaLabel
    : busy
      ? state === 'recording' ? t('recordingTitle') : state === 'transcribing' ? t('transcribingTitle') : t('optimizingTitle')
      : chat.enabled ? t('micTitleHoldChat') : t('micTitle')
  // 长按（语音对话）没有键盘等价手势，但对话热键是等价入口——把它声明给辅助技术。
  // 长按（语音对话）没有键盘等价手势，但对话热键是等价入口——把它声明给辅助技术。
  // 没有对话热键（未启用对话 / 键位清空）时退回声明**录音**热键：SR 用户至少
  // 要知道这个按钮有一个键盘等价入口，而不是「只能点」。
  // aria-keyshortcuts 的值用 ARIA 规范的键名（Ctrl→Control、Cmd→Meta）；
  // `+` 分隔的组合键顺序不敏感，读取方会自行归一。
  const ariaKeyName = (spec: string): string =>
    spec.replace(/\bCtrl\b/gi, 'Control').replace(/\bCmd\b/gi, 'Meta').replace(/\bAlt\b/gi, 'Alt')
  const shortcut = chat.enabled && config.realtime.hotkey !== ''
    ? ariaKeyName(config.realtime.hotkey)
    : (config.behavior.hotkey !== '' ? ariaKeyName(config.behavior.hotkey) : undefined)
  // 两条链路共用一条提示位（同一个 wrap，绝对定位会重叠）。优先级：
  // 对话进行中的字幕 > 录音的错误/提示 > 录音进行中的状态 > 对话留下的提示。
  // 录音在途的状态排在对话「留下的」提示之前——前者是正在发生的事。
  const chatStatus = chat.active || (!busy && error === null && notice === null) ? chat.status : null

  return (
    <react.Fragment>
      <span className="dshav-mic-wrap" ref={wrapRef}>
        <button
          ref={micButtonRef}
          type="button"
          className="dshav-mic-button"
          data-state={chat.active ? chat.phase : state}
          data-mode={chat.active ? 'chat' : 'input'}
          data-chat={chat.enabled ? 'ready' : 'none'}
          aria-label={ariaLabel}
          aria-keyshortcuts={shortcut}
          aria-pressed={chat.active || state === 'recording'}
          disabled={disabled}
          onClick={onButtonClick}
          onPointerDown={onPointerDown}
          onPointerUp={onPointerUp}
          onPointerCancel={onPointerAbort}
          onLostPointerCapture={onPointerAbort}
        >
          {chat.active
            ? (chat.phase === 'listening' ? <RecDot /> : <ChatIcon />)
            : (state === 'recording' ? <RecDot /> : <MicIcon />)}
          {/* 悬停气泡：不依赖浏览器原生 title（自动化浏览器会禁用），文案随系统语言 */}
          <span className="dshav-tooltip" role="tooltip">{title}</span>
          <span className="dshav-wave" aria-hidden="true">
            <span className="dshav-wave-ring" data-ring="1" />
            <span className="dshav-wave-ring" data-ring="2" />
            <span className="dshav-wave-ring" data-ring="3" />
          </span>
        </button>
        {chatStatus !== null ? chatStatus : (
          <react.Fragment>
            {error !== null && (
              <span className="dshav-hotkey-hint" data-kind="err" role="status">
                <span className="dshav-dot" style={{ background: 'var(--dshav-danger)' }} />
                <span className="dshav-hint-text">{error}</span>
                <button type="button" className="dshav-hint-dismiss" aria-label={t('dismiss')} onClick={dismissHint}>×</button>
              </span>
            )}
            {notice !== null && (
              <span className="dshav-hotkey-hint" data-kind="notice" role="status">
                <span className="dshav-dot" />
                <span className="dshav-hint-text">{notice}</span>
                <button type="button" className="dshav-hint-dismiss" aria-label={t('dismiss')} onClick={dismissHint}>×</button>
              </span>
            )}
            {busy && (
              <span className="dshav-hotkey-hint" data-kind="caption" data-state={state} ref={hintRef} role="status">
                {/* 屏幕阅读器只播报**状态词**（每次状态变化一次）；interim 字幕每秒可更新
                    数次，直接喂 live region 会把 SR 用户刷屏（录音中不播报——按下按钮时
                    aria-pressed 已说明状态，真正需要听到的是「正在识别 / 正在优化」）。 */}
                {state !== 'recording' && (
                  <span className="dshav-sr-only">{state === 'transcribing' ? t('transcribingHint') : t('optimizingHint')}</span>
                )}
                {state === 'recording' ? <span className="dshav-dot" /> : <Spinner />}
                {state === 'recording' && interim !== '' ? <span className="dshav-hint-text" aria-hidden="true">{interim}</span> : null}
                {state === 'optimizing' && optimizingDraft ? <span className="dshav-hint-text">{t('optimizingHint')}</span> : null}
                {state === 'transcribing' ? <span className="dshav-hint-text">{t('transcribingHint')}</span> : null}
                {state === 'recording' && (
                  <span className="dshav-spectrum" ref={spectrumRef} aria-hidden="true">
                    <SpectrumBars />
                  </span>
                )}
                {state !== 'recording' && (
                  <button type="button" className="dshav-hint-dismiss" aria-label={t('cancelBusy')} title={t('cancelBusy')} onClick={cancel}>×</button>
                )}
              </span>
            )}
          </react.Fragment>
        )}
      </span>
      {preview !== null && (
        <div
          className="dshav-preview"
          role="dialog"
          aria-modal="true"
          aria-label={t('previewTitle')}
          aria-describedby={previewDescId}
          onKeyDown={(e) => {
            if (e.key === 'Escape') { e.stopPropagation(); closePreview(); return }
            // 焦点陷阱：`role="dialog" + aria-modal="true"` 已经向辅助技术承诺了
            // 「模态」，实现上就得拦住 Tab——否则 SR 用户被告知在模态里，Tab 却
            // 能走到背后的整个 composer，模态承诺落空。卡片只有两个按钮，
            // 用最朴素的循环（不用 focusin 委托，也不引第三方 trap）。
            if (e.key !== 'Tab') return
            const focusables = e.currentTarget.querySelectorAll<HTMLElement>('button')
            if (focusables.length === 0) return
            const first = focusables[0]!
            const last = focusables[focusables.length - 1]!
            const active = document.activeElement
            if (e.shiftKey && (active === first || !e.currentTarget.contains(active))) {
              e.preventDefault(); last.focus()
            } else if (!e.shiftKey && (active === last || !e.currentTarget.contains(active))) {
              e.preventDefault(); first.focus()
            }
          }}
        >
          <div className="dshav-preview-title">
            <MicIcon />
            <span>{t('previewTitle')}</span>
          </div>
          <div className="dshav-preview-body">
            <div className="dshav-preview-block" data-role="original">
              <span className="dshav-preview-label">{t('previewOriginal')}</span>
              <p className="dshav-preview-text" data-role="original">{preview.original}</p>
            </div>
            <div className="dshav-preview-block" data-role="optimized">
              <span className="dshav-preview-label">{t('previewOptimized')}</span>
              <p className="dshav-preview-text" data-role="optimized" id={previewDescId}>{preview.optimized}</p>
            </div>
          </div>
          <div className="dshav-preview-actions">
            <button type="button" className="dshav-button dshav-button-outline dshav-button-sm" onClick={closePreview}>{t('previewCancel')}</button>
            <button ref={previewConfirmRef} type="button" className="dshav-button dshav-button-primary dshav-button-sm" onClick={onConfirm}>
              {config.behavior.autoSend ? t('previewConfirmSend') : t('previewConfirmDraft')}
            </button>
          </div>
        </div>
      )}
    </react.Fragment>
  )
}
