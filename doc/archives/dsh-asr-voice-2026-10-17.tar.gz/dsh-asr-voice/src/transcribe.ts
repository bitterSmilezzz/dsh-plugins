/** dsh-asr-voice — host 半区：云端 ASR 转写代理。
 * 浏览器把原始音频字节 POST 到 /api/asr-voice/transcribe（raw body，
 * Content-Type 为音频 MIME），host 读取配置里的云端 baseUrl/model/mode，按
 * src/key-ref.ts 派生的引用名向 DSH credentials 服务解析 API key，转发到上游并返回
 * { ok, text }。API key 全程只在服务端，不进浏览器。
 * 两条通道（mode）：
 * - transcriptions：whisper 式 multipart /audio/transcriptions（OpenAI / Groq /
 * 硅基流动 / 本地 OpenAI-compatible 部署）。
 * - chat：chat.completions + input_audio（base64 data URI）——小米 MiMo-V2.5-ASR、
 * 通义 qwen3-asr-flash 等「音频大模型」的 OpenAI 兼容姿势。
 * - auto：按模型名自动判定（模型名含 asr/audio/omni/sensevoice 走 chat，否则 transcriptions）。
 * key 复用：引用名与官方 LLM provider 同名（OPENAI_API_KEY / MIMO_API_KEY / …），
 * 用户在 DSH 里配过对应 LLM 就自动共用同一把 key，无需在插件设置里重复粘贴。
 * 纯 Node 全局 fetch/FormData/Blob（Node 18+），跨平台。
 */
import type { Context } from '@deepseek-ai/cordis';
import type { IncomingMessage, ServerResponse } from 'node:http';
import { mkdir, readdir, stat, unlink, writeFile } from 'node:fs/promises';
import { homedir } from 'node:os';
import { join } from 'node:path';
import { CHAT_COMPLETIONS_PATH, MAX_AUDIO_BYTES, TRANSCRIBE_PATH, resolveAsrMode } from './presets.ts';
import { keyRefFor } from './key-ref.ts';
import type { KeyRefSource } from './key-ref.ts';
import { guardRoute, readRawBody, readUpstreamJson, redactSecret, sendJson, statusOfBodyError } from './http.ts';

/** 上游 ASR 请求超时（ms）：上游不可达/卡死时不无限挂起请求。 */
const UPSTREAM_TIMEOUT_MS = 60_000

/** 在途转写请求上限：单请求峰值约 4~5× 音频大小（25MB 音频 → ~120MB 瞬时），而路由
 *  此前没有任何在途计数——一个页面（或本机若干页面）并发几发就能把宿主内存打爆。
 *  超限立刻 503，且**在读取 body 之前**拒绝（拒绝成本最低）。 */
const MAX_INFLIGHT = 4

/** 云端 ASR 配置面（来自 settings scope 解析出的当前生效供应商）。 id / preset / name 由 KeyRefSource 提供，name 是自定义供应商的显示名。 */
export interface CloudAsrConfig extends KeyRefSource {
  baseUrl: string
  /** 遗留密钥位置：一次性迁移完成前仍可直接生效，完成后再无人写入。 */
  apiKey: string
  model: string
  mode: string
}

/** DSH credentials 服务的最小面（可选，供 API key 解析）。 */
interface CredentialsLike {
  resolve(ref: unknown): Promise<{ value?: string } | undefined>
}

/** 模型名 → 上游语言参数（DSH 配置是 auto/zh-CN/en-US，上游要 zh/en）。 */
function upstreamLanguage(language: string | undefined): string | undefined {
  if (!language || language === 'auto') return undefined
  const map: Record<string, string> = { 'zh-CN': 'zh', 'zh': 'zh', 'en-US': 'en', 'en': 'en' }
  return map[language] ?? language
}

/** 从响应里抽错误原因（兼容 { error: string|{message} } 与 { message } 两种形状）。
 *  上游文本一律过 {@link redactSecret}：它会经 reason 直通浏览器并显示给用户，
 *  而上游（或用户自填的 baseUrl）完全可能把 `Bearer <key>` 回显在错误体里。 */
function errorReason(data: { error?: unknown; message?: unknown }, status: number): string {
  if (typeof data.error === 'string' && data.error !== '') return redactSecret(data.error)
  if (typeof data.error === 'object' && data.error !== null) {
    const msg = (data.error as { message?: unknown }).message
    if (typeof msg === 'string' && msg !== '') return redactSecret(msg)
  }
  if (typeof data.message === 'string' && data.message !== '') return redactSecret(data.message)
  return `upstream ASR failed (HTTP ${status})`
}

/** 调试落盘目录：保存浏览器发来的原始音频，便于重放定位（仅诊断用）。 */
function debugDir(): string {
  const env = (globalThis as { process?: { env?: Record<string, string | undefined> } }).process?.env?.DSH_ASR_DEBUG_DIR
  return env && env !== '' ? env : join(homedir(), '.dsh', 'asr-voice-debug')
}

/** 诊断落盘的**总开关**（`DSH_ASR_DEBUG_KEEP_WAVS=1|true|yes` 开启，默认关闭）。
 *  落盘写的是用户的**原始录音**，隐私面远大于诊断价值：此前「静音守卫失败」「识别结果
 *  ≤8 字」「转写失败」三条路径无条件写盘，且 `?capture=1` 是一条任意本机页面都能调用的
 *  写盘原语（信任围栏只管回环，localhost:5173 上的页面同样调得到）。现在默认一条都不落，
 *  开启后连成功样本一起留（诊断期重放用）。 */
function debugCaptureEnabled(): boolean {
  const v = (globalThis as { process?: { env?: Record<string, string | undefined> } }).process?.env?.DSH_ASR_DEBUG_KEEP_WAVS
  return v === '1' || v === 'true' || v === 'yes'
}

/** 从请求 UA 推断浏览器短名（落盘标签用，如 Chrome150/Edge/Safari18）。 */
function uaTag(req: IncomingMessage): string {
  const ua = String(req.headers['user-agent'] ?? '')
  const ver = (re: RegExp): string => {
    const m = ua.match(re)
    return m?.[1] !== undefined ? m[1] : ''
  }
  if (/Edg\//.test(ua)) return `Edge${ver(/Edg\/(\d+)/)}`
  if (/Chrome\//.test(ua)) return `Chrome${ver(/Chrome\/(\d+)/)}`
  if (/Version\//.test(ua) && /Safari\//.test(ua)) return `Safari${ver(/Version\/(\d+)/)}`
  if (/Firefox\//.test(ua)) return `Firefox${ver(/Firefox\/(\d+)/)}`
  return 'UA'
}

/** 目录裁剪上限：文件数 + 总字节数双约束。只按个数裁不够——单个 wav 上限就是
 *  MAX_AUDIO_BYTES（25MB），100 个 = 2.5GB，长期诊断照样撑爆磁盘。 */
const MAX_KEPT_FILES = 100
const MAX_KEPT_BYTES = 200 * 1024 * 1024

/** 裁剪落盘目录：超出文件数或总字节就删最旧的（按 ISO 时间戳文件名排序），
 *  但**永不删刚写的这一条**（否则一次裁剪就把现场删了）。 */
async function pruneDebugDir(dir: string, keepName: string): Promise<void> {
  const names = (await readdir(dir).catch(() => [] as string[])).sort()
  const sizes = new Map<string, number>()
  let total = 0
  for (const name of names) {
    const size = await stat(join(dir, name)).then((s) => s.size).catch(() => 0)
    sizes.set(name, size)
    total += size
  }
  let count = names.length
  for (const name of names) {
    if (count <= MAX_KEPT_FILES && total <= MAX_KEPT_BYTES) break
    if (name === keepName) continue
    await unlink(join(dir, name)).catch(() => {})
    count -= 1
    total -= sizes.get(name) ?? 0
  }
}

/** 把原始音频落盘（fire-and-forget，绝不阻断路由；调用方负责过 {@link debugCaptureEnabled}）。 */
async function saveDebugAudio(audio: Buffer, mime: string, tag: string): Promise<void> {
  try {
    const dir = debugDir()
    await mkdir(dir, { recursive: true })
    const stamp = new Date().toISOString().replace(/[:.]/g, '-')
    const safeTag = tag.replace(/[^a-z0-9]+/gi, '-').slice(0, 40) || 'unknown'
    const name = `${stamp}-${audio.length}B-${safeTag}.${extForMime(mime)}`
    await writeFile(join(dir, name), audio)
    await pruneDebugDir(dir, name)
  } catch {
    // 诊断落盘失败不影响主流程
  }
}

/** whisper 式 multipart /audio/transcriptions。 */
async function upstreamTranscribeMultipart(cfg: CloudAsrConfig, audio: Buffer, mime: string, language: string | undefined, apiKey: string): Promise<{ text: string }> {
  const base = cfg.baseUrl.replace(/\/+$/, '');
  const form = new FormData();
  const ext = extForMime(mime);
  // Buffer → fresh Uint8Array<ArrayBuffer> so it satisfies BlobPart under
  // the DOM/undici typings (Node Buffer is Uint8Array<ArrayBufferLike>).
  const bytes = new Uint8Array(audio.byteLength);
  bytes.set(audio);
  form.append('file', new Blob([bytes], { type: mime }), `recording.${ext}`);
  const model = cfg.model || 'whisper-1';
  form.append('model', model);
  if (language && language !== 'auto') form.append('language', language);
  const res = await fetch(`${base}${TRANSCRIBE_PATH}`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${apiKey}` },
    body: form,
    // 上游卡死时及时失败（客户端 60s 超时后 host 不应继续占着请求）。
    signal: AbortSignal.timeout(UPSTREAM_TIMEOUT_MS),
  });
  // 带上限读上游响应：baseUrl 可指向不可信端点，无上限的 res.json() 是宿主 OOM 入口。
  const data = (await readUpstreamJson(res)) as { text?: unknown; error?: unknown; message?: unknown };
  if (!res.ok) {
    throw new Error(errorReason(data, res.status));
  }
  if (typeof data.text !== 'string' || data.text.trim() === '') {
    throw new Error('upstream ASR returned no text');
  }
  return { text: data.text };
}

/** chat-completions + input_audio（base64 data URI）：MiMo / Qwen-ASR 通道。 */
async function upstreamTranscribeChat(cfg: CloudAsrConfig, audio: Buffer, mime: string, language: string | undefined, apiKey: string): Promise<{ text: string }> {
  const base = cfg.baseUrl.replace(/\/+$/, '');
  const model = cfg.model || 'mimo-v2.5-asr';
  const dataUri = `data:${mime};base64,${audio.toString('base64')}`;
  const lang = upstreamLanguage(language);
  const payload: Record<string, unknown> = {
    model,
    messages: [
      { role: 'user', content: [{ type: 'input_audio', input_audio: { data: dataUri } }] },
    ],
  };
  if (lang !== undefined) payload.asr_options = { language: lang };
  const res = await fetch(`${base}${CHAT_COMPLETIONS_PATH}`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
    signal: AbortSignal.timeout(UPSTREAM_TIMEOUT_MS),
  });
  // 同 multipart 通道：上游响应体带上限读取。
  const data = (await readUpstreamJson(res)) as {
    choices?: { message?: { content?: unknown } }[]
    error?: unknown
    message?: unknown
  };
  if (!res.ok) {
    throw new Error(errorReason(data, res.status));
  }
  // 兼容 content 为字符串或多模态数组（[{type:'text',text:'…'}]）两种形状。
  let content = data.choices?.[0]?.message?.content;
  if (Array.isArray(content)) {
    // 循环拼接替代 map+join：避免为最常见的单元素数组分配中间数组。
    let acc = ''
    for (const p of content) {
      const t = (p as { text?: unknown }).text
      if (typeof t === 'string') acc += t
    }
    content = acc
  }
  if (typeof content !== 'string' || content.trim() === '') {
    throw new Error(`upstream ASR returned no text (${audio.length}B ${mime})`);
  }
  // auto 语言模式会带 <chinese>/<english> 等标签，去掉。
  // 仅在 auto（未显式指定语言）时清洗，且只匹配已知语言标签，
  // 避免误删口述内容中的尖括号（如「用 <div> 包起来」）。
  const text = (lang === undefined
    ? content.replace(/<\/?(?:chinese|english|zh|en|ja|japanese|ko|korean)>/gi, '')
    : content
  ).trim();
  if (text === '') throw new Error(`upstream ASR returned no text (${audio.length}B ${mime})`);
  return { text };
}

/** 按 mode 分发到对应通道。 */
async function upstreamTranscribe(cfg: CloudAsrConfig, audio: Buffer, mime: string, language: string | undefined, apiKey: string): Promise<{ text: string }> {
  const mode = resolveAsrMode(cfg.mode, cfg.model || '');
  if (mode === 'chat') return upstreamTranscribeChat(cfg, audio, mime, language, apiKey);
  return upstreamTranscribeMultipart(cfg, audio, mime, language, apiKey);
}

/** 解析最终 API key：settings 里的遗留值优先（一次性迁移完成前的兼容路径），否则按 派生引用名向 DSH credentials 服务解析，最后退回同名环境变量。预置供应商的引用名与 官方 LLM provider 同名，因此配过对应 LLM 的用户在这里天然命中同一把 key。
 *  凭据服务 `resolve` 的契约是「未配置 → undefined」，**抛错 = 服务真故障**（后端不可用 /
 *  权限拒绝），两者含义完全不同：早先空 catch 把故障吞成「返回空串」，用户看到的是
 *  "no API key" 提示，于是去设置页反复确认凭据明明存在，真实故障被彻底掩盖。现在把故障
 *  原因留到「环境变量也没兜到 key」时抛出——那时真相就是「无法判断有没有 key」，比谎报
 *  「没配 key」诚实。 */
export async function resolveApiKey(ctx: Context, cfg: CloudAsrConfig): Promise<string> {
  const legacy = cfg.apiKey.trim();
  if (legacy !== '') return legacy;
  const ref = keyRefFor(cfg);
  const credentials = ctx.get('credentials') as CredentialsLike | undefined;
  let lookupError: unknown;
  if (credentials !== undefined) {
    try {
      const hit = await credentials.resolve(ref);
      if (hit?.value) return hit.value;
    } catch (error) {
      lookupError = error;
    }
  }
  // 兜底：环境变量（DSH 进程若以 export 方式注入也能读到）。
  const globalProcess = (globalThis as { process?: { env?: Record<string, string | undefined> } }).process;
  const fromEnv = globalProcess?.env?.[ref] ?? '';
  if (fromEnv !== '') return fromEnv;
  if (lookupError !== undefined) {
    const cause = lookupError instanceof Error ? lookupError.message : String(lookupError);
    throw new Error(`credential ${ref} lookup failed: ${cause} — cannot tell whether a key is configured`);
  }
  return '';
}

/** 根据 MIME 推断文件扩展名（用于 multipart filename；不影响转写）。 */
function extForMime(mime: string): string {
  const m = mime.split(';')[0]?.trim().toLowerCase() ?? '';
  const map: Record<string, string> = {
    'audio/webm': 'webm',
    'audio/ogg': 'ogg',
    'audio/mp4': 'm4a',
    'audio/mpeg': 'mp3',
    'audio/wav': 'wav',
    'audio/x-wav': 'wav',
    'audio/x-m4a': 'm4a',
    'audio/aac': 'aac',
    'audio/flac': 'flac',
  };
  return map[m] ?? 'bin';
}

/** 注册 /api/asr-voice/transcribe 路由。
 * 顺序：信任围栏 → 在途上限（超限 503，不读 body）→ 读 body → 上游转发。
 * @param register - webserver 的 register 方法（由调用方从 ctx 传入）。
 * @param getCloudConfig - 读取当前生效云端 ASR 配置的 thunk。
 * @param ctx - host context（供 MiMo key 兜底走 credentials 服务）。
 * @param recordStats - 成功转写后回调（记录用量；可选）。
 * @returns 路由 disposer（由 ctx.effect 挂载/回收）。
 */
export function registerTranscribeRoute(
  register: (def: { kind: 'exact'; path: string; handler: (req: IncomingMessage, res: ServerResponse) => Promise<void> | void }) => () => void,
  getCloudConfig: () => CloudAsrConfig,
  ctx: Context,
  recordStats?: (text: string, providerId: string) => void,
): () => void {
  // 在途计数跨请求共享，故挂在注册闭包里（每个路由实例一份，disposer 回收时随之丢弃）。
  let inflight = 0
  /** 真正的转写处理（在途计数由下方 handler 负责增减）。 */
  const handle = async (req: IncomingMessage, res: ServerResponse): Promise<void> => {
    let audio: Buffer = Buffer.alloc(0)
    let mime = 'audio/webm'
    let ua = 'UA'
    try {
      audio = await readRawBody(req, MAX_AUDIO_BYTES);
      if (audio.length === 0) return sendJson(res, 400, { ok: false, reason: 'empty audio body' });
      mime = String(req.headers['content-type'] ?? 'audio/webm').split(';')[0]?.trim() || 'audio/webm';
      const url = new URL(req.url ?? '/', 'http://localhost');
      // 诊断标记：从请求 UA 推断浏览器，让每个落盘文件的标签自带浏览器身份。
      ua = uaTag(req);
      // 纯抓取请求（诊断）：保存转换前的原始录音后直接返回，不调用上游。默认关闭
      // （见 debugCaptureEnabled）——关闭时仍回合法 JSON，只是不落盘，免得让调用方
      // 以为「抓到了」而拿着空目录排查。
      if (url.searchParams.get('capture') === '1') {
        if (!debugCaptureEnabled()) {
          return sendJson(res, 200, { ok: false, saved: false, reason: 'debug capture disabled: set DSH_ASR_DEBUG_KEEP_WAVS=1 to enable' });
        }
        void saveDebugAudio(audio, mime, `raw-${ua}`);
        return sendJson(res, 200, { ok: true, saved: true });
      }
      const language = url.searchParams.get('language') ?? undefined;
      const cfg = getCloudConfig();
      if (!cfg.baseUrl.trim()) {
        return sendJson(res, 400, { ok: false, reason: 'cloud ASR not configured: set baseUrl in plugin settings' });
      }
      const apiKey = await resolveApiKey(ctx, cfg);
      if (!apiKey) {
        return sendJson(res, 400, { ok: false, reason: `no API key: set the credential ${keyRefFor(cfg)} in DSH (a same-named LLM key is reused automatically)` });
      }
      const { text } = await upstreamTranscribe(cfg, audio, mime, language, apiKey);
      // 诊断抓取（默认关闭）：开启后成功样本也落盘，便于重放定位「听错/幻觉」。
      // 关闭时一条都不写——落盘的是用户的原始录音，隐私优先。
      if (debugCaptureEnabled()) void saveDebugAudio(audio, mime, `${ua}-ok-${text.slice(0, 18)}`);
      // 用量统计（可选，dev 功能）。
      recordStats?.(text, cfg.id);
      return sendJson(res, 200, { ok: true, text });
    } catch (error) {
      const base = error instanceof Error ? error.message : String(error);
      const reason = audio.length > 0 ? `${base} (audio ${audio.length}B, ${mime})` : base;
      // 失败样本同样只在诊断开关打开时落盘（重放定位用，不影响主流程）。
      if (audio.length > 0 && debugCaptureEnabled()) void saveDebugAudio(audio, mime, `${ua}-${base}`);
      // 超限/超时是输入问题（413/408），不该报成 502 把排查引向上游。
      return sendJson(res, statusOfBodyError(error, 502), { ok: false, reason });
    }
  }
  return register({
    kind: 'exact',
    path: '/api/asr-voice/transcribe',
    handler: async (req: IncomingMessage, res: ServerResponse) => {
      const denied = guardRoute(req);
      if (denied !== null) return sendJson(res, denied.status, denied.payload);
      // 在途上限：超限立刻拒绝，连 body 都不读（并发峰值就是内存峰值）。
      if (inflight >= MAX_INFLIGHT) {
        return sendJson(res, 503, { ok: false, reason: 'too many concurrent requests' });
      }
      inflight += 1;
      try {
        await handle(req, res);
      } finally {
        inflight -= 1;
      }
    },
  });
}
