/**
 * Offline smoke test for the Antigravity tool plugin.
 *
 * Loads the plugin with a mock cordis context, points it at a fake `agy`
 * executable, and exercises the success, error-status, empty-answer, and
 * cancellation paths without touching a real Antigravity account.
 */

import { mkdtempSync, writeFileSync, chmodSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import path from 'node:path'
import { apply } from '../index.js'

const dir = mkdtempSync(path.join(tmpdir(), 'agy-smoke-'))
const fakeBin = path.join(dir, 'agy')

/** Write a fake agy that prints $FAKE_OUT and exits with $FAKE_EXIT. */
function installFake(body) {
  writeFileSync(fakeBin, `#!/bin/sh\n${body}\n`)
  chmodSync(fakeBin, 0o755)
}

/** Load the plugin and capture the registered tool definition. */
function loadTool(config) {
  let captured
  const ctx = {
    effect(fn) { return fn() },
    tools: { register(definition) { captured = definition; return () => {} } },
  }
  apply(ctx, config)
  if (!captured) throw new Error('plugin registered no tool')
  return captured
}

const run = (definition, args, signal = new AbortController().signal) =>
  definition.execute(args, { agent: { session: { header: { cwd: dir } } }, signal })

const results = []
const check = (name, ok, detail) => {
  results.push({ name, ok, detail })
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}${detail ? ` — ${detail}` : ''}`)
}

try {
  // 1. Success: a well-formed envelope.
  installFake(`cat > /dev/null
printf '%s' '{"status":"SUCCESS","response":"hello from agy","conversation_id":"conv-123","duration_seconds":4.5}'`)
  const tool = loadTool({ bin: fakeBin, permissionMode: 'skip' })
  const ok = await run(tool, { prompt: 'say hi' })
  check('success envelope returns response text', ok.text === 'hello from agy', JSON.stringify(ok))
  check('success envelope surfaces conversation id', ok.conversationId === 'conv-123')
  check('success envelope surfaces duration', ok.durationSeconds === 4.5)
  check('render emits a text content block', tool.output.render({}, ok)[0]?.type === 'text')

  // 2. JSON preceded by a banner line still parses.
  installFake(`cat > /dev/null
printf 'starting up...\\n'
printf '%s' '{"status":"SUCCESS","response":"after banner"}'`)
  const bannered = await run(tool, { prompt: 'x' })
  check('banner before JSON still parses', bannered.text === 'after banner', bannered.text)

  // 3. Non-SUCCESS status becomes an error.
  installFake(`cat > /dev/null
printf '%s' '{"status":"QUOTA_EXCEEDED","error":"weekly grant spent"}'`)
  let statusError
  try { await run(tool, { prompt: 'x' }) } catch (error) { statusError = error }
  check('non-SUCCESS status throws', statusError instanceof Error && /QUOTA_EXCEEDED/.test(statusError.message),
    statusError?.message)

  // 4. Empty answer becomes an actionable error.
  installFake(`cat > /dev/null
printf '%s' '{"status":"SUCCESS","response":"   "}'`)
  let emptyError
  try { await run(tool, { prompt: 'x' }) } catch (error) { emptyError = error }
  check('empty answer throws with guidance',
    emptyError instanceof Error && /signed in/.test(emptyError.message), emptyError?.message)

  // 5. Non-JSON output becomes an error rather than a silent success.
  installFake(`cat > /dev/null
printf 'not json at all'`)
  let garbageError
  try { await run(tool, { prompt: 'x' }) } catch (error) { garbageError = error }
  check('non-JSON output throws', garbageError instanceof Error && /no JSON envelope/.test(garbageError.message))

  // 5b. The real unsigned-CLI failure is recognised and explained.
  installFake(`cat > /dev/null
printf 'Error: Please sign in to view available models. Launch the CLI without arguments to sign in.\\n' >&2
exit 1`)
  let authError
  try { await run(tool, { prompt: 'x' }) } catch (error) { authError = error }
  check('unsigned CLI reports a sign-in hint',
    authError instanceof Error && /not signed in/.test(authError.message), authError?.message)

  // 5c. Quota exhaustion is distinguished from other failures.
  installFake(`cat > /dev/null
printf 'Individual quota reached. Please upgrade your subscription.\\n' >&2
exit 1`)
  let quotaError
  try { await run(tool, { prompt: 'x' }) } catch (error) { quotaError = error }
  check('quota exhaustion reports a quota hint',
    quotaError instanceof Error && /quota or rate limit/.test(quotaError.message), quotaError?.message)

  // 6. Argument mapping: flags reach the child.
  installFake(`cat > /dev/null
printf '{"status":"SUCCESS","response":"%s"}' "$*"`)
  const mapped = await run(tool, {
    prompt: 'task', model: 'm1', effort: 'high', mode: 'plan', sandbox: true,
    add_dirs: ['/tmp/a'], conversation: 'c9', timeout_seconds: 30,
  })
  const argv = mapped.text
  check('argv carries model/effort/mode', /--model m1/.test(argv) && /--effort high/.test(argv) && /--mode plan/.test(argv), argv)
  check('argv carries sandbox + skip-permissions', /--dangerously-skip-permissions/.test(argv) && /--sandbox/.test(argv))
  check('argv carries add-dir and conversation', /--add-dir \/tmp\/a/.test(argv) && /--conversation c9/.test(argv))
  check('argv carries print-timeout from timeout_seconds', /--print-timeout 30s/.test(argv))

  // 7. permissionMode 'default' omits the skip flag.
  const strict = loadTool({ bin: fakeBin, permissionMode: 'default' })
  const strictOut = await run(strict, { prompt: 'task' })
  check('permissionMode default omits skip flag', !/dangerously-skip-permissions/.test(strictOut.text), strictOut.text)

  // 8. Cancellation terminates the child.
  installFake(`cat > /dev/null
sleep 30
printf '%s' '{"status":"SUCCESS","response":"never"}'`)
  const controller = new AbortController()
  const pending = run(tool, { prompt: 'slow' }, controller.signal)
  setTimeout(() => controller.abort(), 250)
  const started = Date.now()
  let abortError
  try { await pending } catch (error) { abortError = error }
  const elapsed = Date.now() - started
  check('abort rejects promptly', abortError instanceof Error && elapsed < 8000, `${elapsed}ms: ${abortError?.message}`)

  // 9. Timeout terminates the child.
  installFake(`cat > /dev/null
sleep 30
printf '%s' '{"status":"SUCCESS","response":"never"}'`)
  let timeoutError
  try { await run(tool, { prompt: 'slow', timeout_seconds: 1 }) } catch (error) { timeoutError = error }
  check('timeout throws', timeoutError instanceof Error && /exceeded 1s/.test(timeoutError.message), timeoutError?.message)

  // 10. Missing binary is reported, not hung.
  let missingError
  try { await run(tool, { prompt: 'x', cwd: dir }) && loadTool({ bin: '/nonexistent/agy' }) }
  catch (error) { missingError = error }
  const missingTool = loadTool({ bin: '/nonexistent/agy' })
  let spawnError
  try { await run(missingTool, { prompt: 'x' }) } catch (error) { spawnError = error }
  check('missing binary reports an error', spawnError instanceof Error, spawnError?.message)
} finally {
  rmSync(dir, { recursive: true, force: true })
}

const failed = results.filter((r) => !r.ok)
console.log(`\n${results.length - failed.length}/${results.length} checks passed`)
process.exit(failed.length === 0 ? 0 : 1)
