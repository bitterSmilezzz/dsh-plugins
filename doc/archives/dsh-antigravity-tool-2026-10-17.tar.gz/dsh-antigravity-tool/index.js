/**
 * Antigravity tool for DeepSeek Harness.
 *
 * Drives the *official* Antigravity CLI (`agy`) in its documented headless
 * print mode. Authentication stays entirely inside the vendor's own client:
 * this plugin never reads, copies, or forwards credentials — it spawns `agy`
 * and lets `agy` use whatever sign-in the user already established.
 *
 * Headless contract (verified against agy 1.2.6):
 *   agy -p <prompt> --output-format json [--model M] [--effort E] [--mode M]
 *       [--dangerously-skip-permissions] [--sandbox] [--add-dir D]...
 *       [--continue | --conversation ID] [--print-timeout 900s]
 *
 * JSON output is an envelope: { status, response, structured_output?, error?,
 * conversation_id?, duration_seconds?, usage? }.
 */

import { spawn } from 'node:child_process'
import { existsSync } from 'node:fs'
import { homedir } from 'node:os'
import path from 'node:path'

/** Hard ceiling on captured stdout/stderr, to bound memory on a runaway run. */
const OUTPUT_CAP_BYTES = 8 * 1024 * 1024

/** Grace between SIGTERM and SIGKILL when cancelling the child. */
const KILL_GRACE_MS = 3000

const DEFAULT_TIMEOUT_SECONDS = 900

export const inject = ['tools']

/**
 * Resolve the `agy` executable: an explicit path wins, then PATH, then the
 * official installer's default location.
 * @param {string} configured - the configured binary name or path.
 * @returns {string} an executable path or the bare name for PATH resolution.
 */
function resolveBin(configured) {
  const bin = typeof configured === 'string' && configured.length > 0 ? configured : 'agy'
  if (bin.includes('/') || bin.includes('\\')) return bin
  const dirs = (process.env.PATH ?? '').split(path.delimiter).filter(Boolean)
  for (const dir of dirs) {
    const candidate = path.join(dir, bin)
    if (existsSync(candidate)) return candidate
  }
  const fallback = path.join(homedir(), '.local', 'bin', bin)
  if (existsSync(fallback)) return fallback
  return bin
}

/**
 * Parse `agy --output-format json` output, tolerating a banner before the JSON.
 * @param {string} stdout - raw stdout.
 * @returns {object | null} the envelope, or null when nothing parsed.
 */
function parseEnvelope(stdout) {
  const trimmed = stdout.trim()
  if (trimmed.length === 0) return null
  try {
    const direct = JSON.parse(trimmed)
    if (direct && typeof direct === 'object') return direct
  } catch {
    // fall through to brace slicing
  }
  const first = trimmed.indexOf('{')
  const last = trimmed.lastIndexOf('}')
  if (first >= 0 && last > first) {
    try {
      const sliced = JSON.parse(trimmed.slice(first, last + 1))
      if (sliced && typeof sliced === 'object') return sliced
    } catch {
      // not JSON
    }
  }
  return null
}

/**
 * Build the `agy` argv from tool arguments and plugin config.
 * @param {object} args - validated tool arguments.
 * @param {object} cfg - plugin config.
 * @param {number} timeoutSeconds - effective timeout.
 * @returns {string[]} argv (excluding the executable).
 */
function buildArgv(args, cfg, timeoutSeconds) {
  const argv = ['-p', args.prompt, '--output-format', 'json']

  const model = args.model ?? cfg.defaultModel
  if (typeof model === 'string' && model.length > 0) argv.push('--model', model)

  const effort = args.effort ?? cfg.defaultEffort
  if (typeof effort === 'string' && effort.length > 0) argv.push('--effort', effort)

  if (typeof args.mode === 'string' && args.mode.length > 0) argv.push('--mode', args.mode)

  // Without this, print mode silently skips every tool call and the agent
  // degrades to plain chat. `sandbox` layers terminal restrictions on top.
  const permissionMode = cfg.permissionMode ?? 'skip'
  const skip = args.skip_permissions ?? permissionMode === 'skip'
  if (skip) argv.push('--dangerously-skip-permissions')
  if (args.sandbox === true) argv.push('--sandbox')

  for (const dir of args.add_dirs ?? []) {
    if (typeof dir === 'string' && dir.length > 0) argv.push('--add-dir', dir)
  }

  if (typeof args.conversation === 'string' && args.conversation.length > 0) {
    argv.push('--conversation', args.conversation)
  } else if (args.continue_conversation === true) {
    argv.push('--continue')
  }

  argv.push('--print-timeout', `${timeoutSeconds}s`)
  return argv
}

/**
 * Spawn `agy`, honouring cancellation, and capture bounded output.
 * @param {string} bin - executable.
 * @param {string[]} argv - arguments.
 * @param {string} cwd - working directory.
 * @param {number} timeoutMs - hard wall-clock limit.
 * @param {AbortSignal} signal - caller cancellation.
 * @returns {Promise<{ stdout: string, stderr: string, code: number | null, signal: string | null, timedOut: boolean }>}
 */
function runProcess(bin, argv, cwd, timeoutMs, signal) {
  return new Promise((resolve, reject) => {
    // `agy` spawns its own children (shells, language servers). Putting the
    // child in its own process group lets cancellation reach the whole tree;
    // killing only the direct child leaves grandchildren holding the stdout
    // pipe open, so `close` would not fire until they finish on their own.
    const grouped = process.platform !== 'win32'
    let child
    try {
      child = spawn(bin, argv, { cwd, stdio: ['ignore', 'pipe', 'pipe'], detached: grouped })
    } catch (error) {
      reject(new Error(`Failed to start '${bin}': ${error instanceof Error ? error.message : String(error)}`))
      return
    }

    let stdout = ''
    let stderr = ''
    let timedOut = false
    let settled = false

    const append = (current, chunk) =>
      current.length >= OUTPUT_CAP_BYTES ? current : (current + chunk).slice(0, OUTPUT_CAP_BYTES)

    child.stdout?.on('data', (chunk) => { stdout = append(stdout, chunk.toString()) })
    child.stderr?.on('data', (chunk) => { stderr = append(stderr, chunk.toString()) })

    const killTree = (signalName) => {
      try {
        if (grouped && typeof child.pid === 'number') process.kill(-child.pid, signalName)
        else child.kill(signalName)
      } catch {
        try { child.kill(signalName) } catch { /* already gone */ }
      }
    }

    const finish = (payload) => {
      if (settled) return
      settled = true
      cleanup()
      resolve(payload)
    }

    const fail = (error) => {
      if (settled) return
      settled = true
      cleanup()
      reject(error)
    }

    let killTimer
    const terminate = () => {
      if (child.exitCode !== null || child.signalCode !== null) return
      killTree('SIGTERM')
      killTimer = setTimeout(() => {
        killTree('SIGKILL')
        // A process group that ignores SIGKILL cannot exist, but a stuck pipe
        // can still delay `close`; settle on the captured output regardless.
        const graceTimer = setTimeout(() => {
          finish({ stdout, stderr, code: child.exitCode, signal: child.signalCode, timedOut })
        }, KILL_GRACE_MS)
        graceTimer.unref?.()
      }, KILL_GRACE_MS)
      killTimer.unref?.()
    }

    const onAbort = () => { terminate() }
    if (signal) {
      if (signal.aborted) onAbort()
      else signal.addEventListener('abort', onAbort, { once: true })
    }

    const timer = setTimeout(() => { timedOut = true; terminate() }, timeoutMs)
    timer.unref?.()

    function cleanup() {
      clearTimeout(timer)
      clearTimeout(killTimer)
      signal?.removeEventListener('abort', onAbort)
    }

    child.on('error', (error) => {
      fail(new Error(`Antigravity CLI failed to run: ${error.message}`))
    })

    child.on('close', (code, closeSignal) => {
      finish({ stdout, stderr, code, signal: closeSignal, timedOut })
    })
  })
}

/**
 * Mount the Antigravity tool.
 * @param {import('@deepseek-ai/cordis').Context} ctx - plugin context.
 * @param {object} [config] - row config.
 */
export function apply(ctx, config) {
  const cfg = config ?? {}
  const bin = resolveBin(cfg.bin)

  ctx.effect(() => ctx.tools.register({
    name: 'antigravity_run',
    description:
      'Delegate a self-contained coding or research task to Google Antigravity, running headlessly through the '
      + "official `agy` CLI on the user's own Antigravity sign-in. The agent works in the given directory, may edit "
      + 'files and run commands there, and returns only its final answer. Use it for work that benefits from a second '
      + 'independent agent, or when the user explicitly asks for Antigravity. Antigravity shares one weekly free '
      + 'quota across its desktop app, CLI, and SDK, so prefer one well-scoped call over many small ones.',
    parameters: {
      type: 'object',
      additionalProperties: false,
      properties: {
        prompt: {
          type: 'string',
          description: 'The complete, self-contained task. The Antigravity agent sees only this text, not this conversation.',
        },
        cwd: {
          type: 'string',
          description: 'Absolute working directory for the Antigravity agent. Defaults to this session working directory.',
        },
        add_dirs: {
          type: 'array',
          items: { type: 'string' },
          description: 'Extra absolute directories to add to the Antigravity workspace.',
        },
        model: { type: 'string', description: 'Model for this run. Omit to use the Antigravity default.' },
        effort: { type: 'string', enum: ['low', 'medium', 'high'], description: 'Reasoning effort for this run.' },
        mode: {
          type: 'string',
          enum: ['accept-edits', 'plan'],
          description: "Agent execution mode: 'plan' returns a plan without editing; 'accept-edits' applies edits.",
        },
        sandbox: {
          type: 'boolean',
          description: 'Run with Antigravity terminal restrictions enabled. Safer, but restricts shell access.',
        },
        skip_permissions: {
          type: 'boolean',
          description: 'Override the profile default for auto-approving tool permissions.',
        },
        conversation: {
          type: 'string',
          description: 'Resume a specific Antigravity conversation id returned by an earlier call.',
        },
        continue_conversation: {
          type: 'boolean',
          description: 'Continue the most recent Antigravity conversation instead of starting a new one.',
        },
        timeout_seconds: {
          type: 'number',
          description: `Wall-clock limit for the run in seconds. Defaults to ${DEFAULT_TIMEOUT_SECONDS}.`,
        },
      },
      required: ['prompt'],
    },
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          text: { type: 'string' },
          conversationId: { type: 'string' },
          durationSeconds: { type: 'number' },
          exitCode: { type: 'integer' },
        },
        required: ['text'],
      },
      render(_args, value) {
        const text = typeof value?.text === 'string' ? value.text : ''
        const id = typeof value?.conversationId === 'string' && value.conversationId.length > 0 ? value.conversationId : null
        const suffix = id === null
          ? ''
          : `\n\n---\nAntigravity conversation id: ${id} (pass as \`conversation\` to continue this thread)`
        return [{ type: 'text', text: text + suffix }]
      },
    },
    timeoutMs: 3_600_000,
    // Antigravity drains one shared weekly quota; serialize rather than fan out.
    isConcurrencySafe: () => false,
    presentCall(args) {
      const prompt = typeof args?.prompt === 'string' ? args.prompt : ''
      return {
        card: 'terminal',
        title: 'Antigravity',
        description: prompt.length > 160 ? `${prompt.slice(0, 160)}…` : prompt,
        ...(typeof args?.cwd === 'string' ? { cwd: args.cwd } : {}),
      }
    },
    async execute(args, exec) {
      const timeoutSeconds = Number.isFinite(args.timeout_seconds) && args.timeout_seconds > 0
        ? Math.floor(args.timeout_seconds)
        : DEFAULT_TIMEOUT_SECONDS

      const cwd = typeof args.cwd === 'string' && args.cwd.length > 0
        ? args.cwd
        : (exec.agent?.session?.header?.cwd ?? process.cwd())

      const argv = buildArgv(args, cfg, timeoutSeconds)
      const result = await runProcess(bin, argv, cwd, timeoutSeconds * 1000 + KILL_GRACE_MS, exec.signal)

      if (result.timedOut) {
        throw new Error(`Antigravity run exceeded ${timeoutSeconds}s and was terminated.`)
      }
      if (exec.signal?.aborted) {
        throw new Error('Antigravity run was cancelled.')
      }

      const envelope = parseEnvelope(result.stdout)

      if (envelope === null) {
        const stderr = result.stderr.trim()
        // Observed on a fresh install: `agy` keeps its own session and does not
        // reuse the Antigravity IDE credentials under ~/.gemini.
        if (/sign in|not signed in|unauthenticated|login required/i.test(stderr)) {
          throw new Error(
            'Antigravity CLI is not signed in. Run `agy` once interactively to complete its sign-in, then retry; '
            + 'the CLI keeps its own session and does not reuse the Antigravity IDE credentials.',
          )
        }
        if (/quota|rate limit|too many requests/i.test(stderr)) {
          throw new Error(`Antigravity quota or rate limit reached: ${stderr.slice(0, 400)}`)
        }
        const detail = stderr || result.stdout.trim() || 'no output'
        throw new Error(
          `Antigravity CLI returned no JSON envelope (exit ${result.code ?? 'null'}): ${detail.slice(0, 800)}`,
        )
      }

      if (typeof envelope.status === 'string' && envelope.status !== 'SUCCESS') {
        const detail = typeof envelope.error === 'string' && envelope.error.trim().length > 0
          ? ` ${envelope.error.trim()}`
          : ''
        throw new Error(`Antigravity CLI reported status ${envelope.status}.${detail}`)
      }

      let text = ''
      if (typeof envelope.response === 'string') text = envelope.response
      else if (envelope.structured_output !== undefined) text = JSON.stringify(envelope.structured_output, null, 2)

      if (text.trim().length === 0) {
        const detail = result.stderr.trim()
        throw new Error(
          `Antigravity returned an empty answer (exit ${result.code ?? 'null'}).`
          + ' Check that `agy` is signed in and its weekly quota has not run out.'
          + (detail.length > 0 ? ` stderr: ${detail.slice(0, 400)}` : ''),
        )
      }

      return {
        text,
        ...(typeof envelope.conversation_id === 'string' ? { conversationId: envelope.conversation_id } : {}),
        ...(typeof envelope.duration_seconds === 'number' ? { durationSeconds: envelope.duration_seconds } : {}),
        ...(typeof result.code === 'number' ? { exitCode: result.code } : {}),
      }
    },
  }))
}
